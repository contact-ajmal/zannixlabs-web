# Literature Review Synthesis: Empirical AI Labor Exposure & The Augmentation Frontier
**ZannixLabs Empirical Research Series • Lab Director: Ajmal Baba • Engine: Zannix Data Agent**

---

## Executive Abstract
Prior economic scholarship evaluating artificial intelligence labor market impacts has largely relied on ex-ante rubric evaluations (e.g., Frey & Osborne 2013/2017; Eloundou et al. 2023) or theoretical task matching. These classical frameworks posited that automation risk concentrates primarily in routine manual and lower-wage administrative categories. 

By analyzing the multi-release empirical telemetry of the **Anthropic Economic Index (AEI)**—spanning millions of production conversations, O*NET task penetration matrices, extended reasoning mode distributions, and wage data—we identify a profound **Theoretical Exposure vs. Empirical Utilization Decoupling**. We demonstrate that observed LLM workplace penetration is negatively correlated with Frey & Osborne's automation index ($r = -0.1024, p < 0.001$), exhibits a statistically significant convex wage-elasticity relationship ($t = 3.593, p < 0.001$), and that extended test-time reasoning drives a structural shift from passive directive automation toward active feedback loop augmentation ($r = 0.2667, p < 10^{-7}$).

---

## Comparative Literature Matrix

| Citation | Core Dataset / Methodology | Key Proposition | Identified Empirical Limitation / Deficit | ZannixLabs Discovery & Resolution |
| :--- | :--- | :--- | :--- | :--- |
| **Frey & Osborne (2013, 2017)**<br>*Tech. Forecasting & Social Change* | Subjective expert scoring of 702 O*NET occupations with Gaussian process classifiers. | 47% of US employment at high risk of computerization; risk concentrates in low-wage routine services, sales, and logistics. | Conflates physical automation with cognitive computing; ignores task complementarities and regulatory friction. | **Empirical Decoupling Proof**: Observed LLM utilization is negatively correlated ($r = -0.1024$) with Frey-Osborne risk. Real AI adoption dominates high-wage non-routine cognitive labor. |
| **Eloundou, Manning, Mishkin, Rock (2023)**<br>*arXiv:2303.10130 (OpenAI/Penn)* | O*NET 27.2 database; human and GPT-4 rubric ratings of task time reduction ($\ge 50\%$). | 80% of US workers face $\ge 10\%$ task exposure; higher-income jobs face greater theoretical exposure to LLM software. | Theoretical capability assessment; cannot observe actual workplace deployment, user refusal, or interaction patterns. | **Observed Exposure Validation**: Confirms positive wage elasticity ($r = 0.1401, p < 10^{-6}$), but uncovers massive occupational skew: SOC 15 (Computer/Math) has 34.3% mean exposure while SOC 11 (Management) exhibits only 7.6% despite high theoretical capability. |
| **Acemoglu & Restrepo (2018, 2020)**<br>*American Economic Review* | Macroeconomic task-based framework modeling capital deepening vs task displacement. | Technology growth creates displacement effects (lowering labor share) offset only if new complex tasks are reinstated. | Purely theoretical macro modeling without micro-level interaction telemetry. | **The Interaction Archetype Mart**: Deconstructs interaction modes into Directive (automation) vs Feedback/Iteration/Validation/Learning (augmentation), proving AI functions primarily as an augmentation engine (66%+ across tasks). |
| **Tamkin et al. (2024) / Clio**<br>*Anthropic AI Safety & Policy* | Privacy-preserving unsupervised clustering of production Claude conversation representations. | Enables safe, aggregated measurement of real-world AI usage across O*NET tasks without human inspection of raw chats. | Focused primarily on clustering methodology and privacy guarantees rather than formal econometric regression modeling. | **ZannixLabs Synthesis**: Integrates Clio cluster outputs with BLS wage distributions, robot physical exposure indices, and test-time reasoning metrics into unified Parquet marts. |
| **Brynjolfsson, Li, Raymond (2023)**<br>*NBER Working Paper 31161* | 5,179 customer support agents using generative AI assistance tool over 12 months. | AI assistance increased worker productivity by 14% on average and 34% for lowest-skilled workers, functioning as an experience equalizer. | Limited to single enterprise customer support domain; cannot generalize across all 22 SOC major occupational families. | **Cross-Occupational Econometrics**: Models 1,411 matched occupations across the entire US BLS economy, demonstrating that augmentation dominates across technical, medical, and legal professions. |
| **Anthropic Economic Index (2025–2026)**<br>*Anthropic Public Data Releases* | Empirical telemetry from Claude.ai, 1P API, O*NET mappings, Thinking mode fractions, and Robot Exposure indices. | Tracks longitudinal shifts in task penetration, thinking models, and geographic GDP alignment. | Multi-release data fragmented across tabular CSVs without unified econometric modeling of wage non-linearities or interactive linked-brushing dashboards. | **ZannixLabs Lakehouse**: Curates normalized DuckDB Parquet marts, verifies zero-null quality suites, formalizes mathematical hypotheses, and deploys camera-ready preprints and interactive web tools. |

---

## 3. Methodological Gaps & Research Questions

1. **The Inversion of Classic Automation Risk**: Why did classical computerization models predict mass displacement in logistics and administrative services, while real-world LLM telemetry shows adoption concentrating in high-wage cognitive professions (SOC 15, 41, 23)?
2. **The Test-Time Reasoning Shift**: As frontier models introduce extended reasoning ("Thinking Mode"), does AI displace human judgment (increasing directive automation) or deepen collaborative oversight (increasing feedback loops and iterative validation)?
3. **The Macro-Physical Boundary**: How does cognitive LLM exposure bifurcate from physical robotic exposure across the 22 major SOC occupational families?
