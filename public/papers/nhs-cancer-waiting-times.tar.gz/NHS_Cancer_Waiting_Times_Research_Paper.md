# The Diagnostic Triage vs. Definitive Treatment Decoupling: A Nationwide Econometric and Queueing Evaluation of the English NHS Cancer Waiting Times Reform (2019–2026)

**Authors**: Health Economics, Operations Research & Clinical Informatics Collaborative  
**Affiliation**: NHS Health Systems & Policy Analytics Consortium  
**Data Repository**: NHS England Official Statistics (2009–2026 Releases) | Zaanix DuckDB Lakehouse Workspace `76399c8f-81db-4db2-b277-652dcea8527e`  
**Date**: October 2026  

---

## Abstract

**Background**: In October 2023, the National Health Service (NHS) in England enacted the most extensive structural overhaul of cancer performance monitoring in over a decade, consolidating ten legacy operational metrics into three core standards: the 28-Day Faster Diagnosis Standard (FDS; target 80%), the 31-Day Decision-to-Treat Standard (target 96%), and the 62-Day Urgent Referral-to-Treatment Standard (target 85%). While intended to accelerate clinical pathways and reduce administrative overhead, the systemic operational interactions between diagnostic triage and definitive therapeutic intervention under this new framework have remained unexamined at national scale.

**Methods**: We conducted a nationwide longitudinal panel study integrating official monthly and quarterly NHS England Cancer Waiting Times (CWT) data from April 2021 to August 2026, comprising 247,636 provider-pathway records across all 137 active acute hospital trusts, 7 NHS regions, and 16 canonical tumour categories. We evaluated four primary empirical dimensions: (1) Interrupted Time-Series (ITS) segmented regressions with Newey-West heteroscedasticity-and-autocorrelation-consistent (HAC) standard errors across 53 consecutive monthly cycles; (2) Paired hypothesis testing ($t$-test and Wilcoxon signed-rank) on newly released quarterly FDS cohorts disaggregated by diagnostic outcome (Malignant Diagnosis vs. Benign Rule-Out); (3) Cross-tumour elasticity and bottleneck queueing analysis; and (4) Cross-trust multivariate regressions and spatial inequality decomposition (Gini and Theil indices) before and after the April 2026 Integrated Care Board (ICB) structural reorganizations.

**Results**:
1. **The 'Rule-Out Illusion' & Malignancy Triage Deficit (MTD)**: National headline compliance with the 28-day FDS averaged 78.56% in August 2026, approaching the 80% operational target. However, outcome-stratified analysis revealed that this performance is driven by the 93.8% of referrals where cancer is ruled out (79.53% compliance in 2026/27 Q1). Conversely, patients confirmed to have malignant neoplasm experienced a compliance rate of only 54.83%—representing an acute, statistically overwhelming **24.70 to 25.06 percentage point Malignancy Triage Deficit** ($t = 18.383, p = 1.88 \times 10^{-38}$; Wilcoxon $W = 47.0, p = 1.91 \times 10^{-23}$).
2. **Interrupted Time-Series of the October 2023 Reform**: Prior to the reform, 62-day treatment compliance exhibited secular decay ($\beta_1 = -0.1141\%$ per month, $p = 0.086$). The October 2023 policy generated a statistically significant step increase ($\beta_2 = +2.0690\%$, $p = 0.038$) and a positive slope change ($\beta_3 = +0.2845\%$ per month, $p < 0.001$). However, the realized net post-reform recovery rate (+0.1704% per month; +2.04 pp per annum) implies that reaching the 85% national target will require 6.4 years (projected late 2032/early 2033), significantly overshooting the government's statutory March 2029 target.
3. **Anatomical Pathway Decoupling**: Throughput decoupling is strongly bimodal. Direct-access visual pathways (Skin: 85.59% 62-day compliance; Breast: 70.92%) sustain high volumes with limited systemic friction. By contrast, complex multi-modality diagnostic pathways face acute operational decoupling: Head & Neck (+19.18 pp decoupling gap; 56.68% 62-day compliance), Lung (+18.85 pp gap; 61.09% 62-day compliance), Gynaecological (+9.45 pp gap; 57.47% 62-day compliance), and Lower Gastrointestinal/Colorectal (+5.73 pp gap; 58.79% 62-day compliance).
4. **Spatial Inequality & Decoupling Fragmentation**: While front-end diagnostic compliance is relatively uniform across England (Gini = 0.0404), 62-day treatment compliance exhibits nearly double the spatial inequality (Gini = 0.0778), and the Decoupling Gap shows profound geographic disparity (Gini = 0.1781). The regional decoupling penalty is highest in the Midlands (+11.83 pp gap) and North East & Yorkshire (+8.14 pp gap).
5. **Cross-Trust Determinants**: Across 134 acute trusts, each 10 pp increase in a trust's Malignancy Triage Deficit expands its Decoupling Gap by +2.07 pp ($p = 0.006$), whereas each 10 pp improvement in 31-day decision-to-treat throughput compresses the gap by -6.62 pp ($p < 0.001$).

**Conclusions**: The 2023 NHS cancer waiting times reform succeeded in focusing clinical systems on rapid diagnostic exclusion, but inadvertently exacerbated a decoupling between diagnostic triage and definitive therapy. Without ring-fenced surgical theater capacity, pathology turnaround acceleration, and downstream treatment coordination, front-end triage targets function as a "pipeline illusion." Policy must transition from disjointed time checkpoints to end-to-end pathway capacity planning.

---

## 1. Introduction and Policy Context

Timely diagnosis and rapid initiation of definitive therapy are foundational determinants of cancer survival. Across common solid tumours, delays exceeding 4 to 8 weeks from initial presentation to treatment are associated with elevated stage progression, upstaging from localized to locally advanced disease, compromised resectability, and an estimated 6–13% increase in mortality risk across breast, colorectal, and lung malignancies (Hanna et al., 2020; Sud et al., 2020; Maringe et al., 2020).

For nearly two decades, the English National Health Service monitored cancer access through a matrix of ten distinct standards established under the NHS Cancer Plan (2000) and the Cancer Reform Strategy (2007). Central among these were the Two-Week Wait (2WW) standard (requiring 93% of patients urgently referred by a primary care physician to see a hospital specialist within 14 days), the 31-Day First Treatment Standard (96% target from decision-to-treat to treatment), and the 62-Day Urgent Referral-to-Treatment Standard (85% target from GP referral to first definitive therapeutic intervention).

By 2022–2023, this ten-standard architecture faced acute criticism from clinical leaders and health economists. The 2WW standard incentivized hospital trusts to prioritize an initial outpatient consultation within 14 days—often consisting of routine history-taking—rather than performing definitive diagnostic tests, creating administrative friction and "clock-stopping" gaming (Quinn et al., 2024; Johnson, 2024). Concurrently, rapid increases in annual urgent suspected cancer referrals (surpassing 3 million annually, up from ~900,000 in 2009/10) overwhelmed specialist clinics.

### The October 2023 Reform
In response to recommendations from the Independent Cancer Taskforce and the Clinical Review of Standards, NHS England implemented a structural reform effective October 2023:
1. **The 28-Day Faster Diagnosis Standard (FDS)**: Mandated that patients referred urgently by a GP, via breast screening, or through specialist triage must be formally diagnosed with cancer or have cancer definitively excluded within 28 days (operational target set at 75%, subsequently stepped up to 80%).
2. **The 31-Day Combined Standard**: Merged the previous first and subsequent treatment standards into a unified metric requiring 96% of cancer patients to commence definitive treatment (surgical resection, systemic chemotherapy, radiotherapy, or active surveillance) within 31 days of a formal multidisciplinary decision-to-treat.
3. **The 62-Day Combined Standard**: Unified GP urgent referrals, national screening invitations, and consultant upgrades into a single metric requiring 85% of diagnosed cancer patients to start definitive treatment within 62 days of initial referral.

### Literature Gaps and Research Objectives
While initial clinical commentary welcomed the streamlined framework (Johnson, 2024), quantitative evaluations of its system-wide performance have remained limited:
- Prior empirical studies examined either the pre-reform period (Quinn et al., 2024, examining threshold manipulation density up to 2022) or focused narrowly on single specialties such as teledermatology (Carson et al., 2026; Nour et al., 2026) or local hospital cost modeling (Butnari et al., 2025).
- Lam et al. (2026) demonstrated persistent between-trust disparities in patient experience but did not model the operational throughput mechanics of the new three-standard operating framework.
- Crucially, no existing peer-reviewed study has investigated whether the Faster Diagnosis Standard exhibits an endogenous **"Rule-Out Illusion"**—whereby high volumes of rapid benign exclusions artificially inflate headline compliance while confirmed cancer cases encounter acute bottlenecks.

This paper delivers the first comprehensive, nationwide econometric and queueing evaluation of the English NHS Cancer Waiting Times reform, leveraging granular provider-level extracts, quarterly diagnostic outcome cohorts, and long-term national time-series datasets spanning April 2021 through August 2026.

---

## 2. Theoretical Framework and Hypotheses

To model the operational dynamics of the three-standard framework, we conceptualize the hospital cancer pathway as a multi-stage tandem queue with stochastic arrivals, multi-class branching, and shared downstream capital constraints:

$$\text{Referral} \xrightarrow{\lambda} \text{Triage \& Diagnostic Queue } (Q_1, \mu_1) \xrightarrow{p_{\text{mal}}} \text{Treatment Staging \& Theatre Queue } (Q_2, \mu_2)$$

Patients enter Stage 1 ($Q_1$) with arrival rate $\lambda_t$. Following diagnostic investigation (imaging, endoscopy, biopsy, histopathology), the cohort bifurcates:
- A fraction $1 - p_{\text{mal}}$ (empirically ~92–94%) is found to have benign pathology and is discharged or referred to routine outpatient care. For these patients, the pathway terminates upon communication of the negative result ($T_{\text{FDS}} \le 28$ days).
- A fraction $p_{\text{mal}}$ (~6–8%) is diagnosed with confirmed malignancy. These patients require secondary staging (PET-CT, MRI, genetic profiling), multidisciplinary team (MDT) review, pre-operative anesthetic assessment, and definitive treatment allocation in Stage 2 ($Q_2$).

Stage 2 represents a severely constrained capacity server $\mu_2$, governed by physical infrastructure: operative surgical suites, critical care recovery beds, linear accelerator (Linac) radiotherapy slots, and systemic oncology infusion chairs.

From this queueing topology, we derive five empirically testable hypotheses:

* **Hypothesis 1 (The Malignancy Triage Deficit)**: Because benign rule-outs require only a single definitive negative investigation (e.g., negative faecal immunochemical test [FIT], normal mammogram, clear dermoscopy), their service time is significantly shorter than malignant diagnoses, which require histological biopsy, immunohistochemistry, and MDT review. Consequently:
  $$H_1: \quad \text{Compliance}_{\text{Rule-Out}} \gg \text{Compliance}_{\text{Diagnosed}}$$
  and the headline FDS metric will systematically overstate diagnostic timeliness for actual cancer patients.

* **Hypothesis 2 (Triage-to-Treatment Decoupling)**: If hospital investments (such as Community Diagnostic Centres [CDCs] and straight-to-test protocols) expand Stage 1 capacity ($\mu_1$) without corresponding expansions in Stage 2 surgical and therapeutic capacity ($\mu_2$), then:
  $$H_2: \quad \text{Decoupling Gap } \Delta_i = \text{FDS}_i - \text{Wait62}_i > 0$$
  and $\Delta_i$ will widen over time as front-end referral volumes surge.

* **Hypothesis 3 (Interrupted Time Series Structural Shift)**: The October 2023 consolidation eliminated the 14-day 2WW intermediate milestone, removing clinical focus on booking early outpatient appointments. Under segmented regression:
  $$H_3: \quad \beta_2 > 0 \text{ (discrete level shift)}, \quad \beta_3 > 0 \text{ (positive trajectory inflection in 62-day treatment)}$$
  However, if downstream capacity constraints remain binding, $\beta_3$ will be insufficient to achieve the national 85% target within the government's 2029 planning horizon.

* **Hypothesis 4 (Anatomical Pathway Heterogeneity)**: Pathways where diagnosis and definitive treatment can occur in ambulatory or single-modality settings (e.g., Skin cancer via excisional biopsy/teledermatology) will exhibit minimal decoupling ($\Delta \approx 0$). Conversely, pathways requiring complex multi-stage diagnostic workups and major inpatient surgery (Head & Neck, Lung, Colorectal, Prostate) will exhibit severe decoupling ($\Delta \gg 0$).

* **Hypothesis 5 (Spatial Inequality Divergence)**: While centralized diagnostic mandates and CDC funding generate spatial convergence in FDS compliance ($G_{\text{FDS}} \approx 0$), localized constraints in surgical theater staffing and acute bed occupancy will perpetuate high geographic inequality in 62-day treatment ($G_{62} \gg G_{\text{FDS}}$).

---

## 3. Data and Econometric Methodology

### 3.1 Data Sources and Lakehouse Pipeline
All datasets were extracted directly from official NHS England Statistical Work Area releases and ingested into an enterprise-grade sandboxed DuckDB lakehouse inside the Zaanix MCP server (`76399c8f-81db-4db2-b277-652dcea8527e`):
1. **National Time Series with Revisions (2009–2026)**: Monthly national activity, compliance rates, and breach volumes for FDS (28-day), 31-day, and 62-day standards from April 2021 to August 2026 (65 consecutive monthly cycles), and monthly urgent referrals seen from October 2009 to August 2026 (203 consecutive monthly cycles).
2. **Provider-Level Longitudinal Extracts (2024–2026)**: Disaggregated monthly records spanning Financial Years 2024/25, 2025/26, and 2026/27 (April–August provisional), comprising 247,636 rows across 185 reporting providers and 16 tumour categories.
3. **Quarterly FDS Pathway Outcome Cohorts (2025–2026)**: Newly instituted quarterly collections (2025/26 Q3, 2025/26 Q4, and 2026/27 Q1) recording patient-level diagnostic outcomes disaggregated into *Diagnosis of cancer*, *Ruling out of cancer*, and *Other*.
4. **Wait Duration Distributions**: Granular interval distributions recording completed pathways within $<14$ days, 15–28 days, 29–42 days, 43–62 days, 63–76 days, 77–90 days, 91–104 days, and $>104$ days (the extreme backlog tier).

### 3.2 Econometric Specifications

#### Model 1: Segmented Interrupted Time Series (ITS)
To evaluate the structural impact of the October 2023 Three-Standard Reform on 62-day treatment compliance, we estimate a segmented linear regression model:

$$Y_t = \beta_0 + \beta_1 T_t + \beta_2 D_t + \beta_3 P_t + \epsilon_t$$

Where:
- $Y_t$ is the national 62-day treatment compliance percentage in month $t$ ($t = 1, \dots, 53$, covering April 2022 to August 2026 under the unified definition).
- $T_t$ is a continuous time trend variable counting months elapsed from baseline ($T_1 = 0$).
- $D_t$ is an indicator dummy variable set to $0$ for pre-reform months ($t < \text{October 2023}$) and $1$ for post-reform months ($t \ge \text{October 2023}$).
- $P_t$ is an interaction term representing months elapsed since the reform: $P_t = 0$ for $t < \text{October 2023}$, and $P_t = T_t - T_{\text{reform}}$ thereafter.
- $\beta_1$ estimates the pre-reform secular trend.
- $\beta_2$ estimates the immediate discrete intercept change attributable to the policy change.
- $\beta_3$ represents the post-reform trajectory slope alteration. The post-reform secular trend is given by $\beta_1 + \beta_3$.
- Standard errors are estimated using Newey-West heteroscedasticity-and-autocorrelation-consistent (HAC) covariance matrices with a Bartlett lag truncation parameter of 3.

#### Model 2: Paired Malignancy Triage Deficit Testing
For each hospital trust $i$, we define the Malignancy Triage Deficit ($\text{MTD}_i$) as:

$$\text{MTD}_i = \text{Compliance}_{i, \text{Rule-Out}} - \text{Compliance}_{i, \text{Diagnosed}}$$

We test the directional null hypothesis $H_0: \mathbb{E}[\text{MTD}_i] \le 0$ against the alternative $H_1: \mathbb{E}[\text{MTD}_i] > 0$ using both parametric paired $t$-tests and non-parametric Wilcoxon signed-rank tests across $n = 135$ paired hospital trusts.

#### Model 3: Cross-Trust Decoupling Determinants
To isolate the institutional and clinical drivers of the Decoupling Gap ($\Delta_i = \text{FDS}_i - \text{Wait62}_i$), we estimate:

$$\Delta_i = \alpha + \gamma_1 \ln(\text{Referrals}_i) + \gamma_2 \text{Wait31}_i + \gamma_3 \text{MTD}_i + \mathbf{X}_i' \boldsymbol{\theta} + u_i$$

Where $\ln(\text{Referrals}_i)$ captures scale and referral congestion, $\text{Wait31}_i$ reflects internal therapeutic execution speed, $\text{MTD}_i$ proxies diagnostic disparity, and standard errors are adjusted for arbitrary heteroscedasticity using White/MacKinnon-White HC1 estimators.

#### Model 4: Spatial Gini Decomposition
Spatial inequality across trusts is calculated via the normalized Gini coefficient:

$$G = \frac{\sum_{i=1}^n \sum_{j=1}^n |y_i - y_j|}{2 n^2 \bar{y}}$$

evaluated independently for FDS compliance ($G_{\text{FDS}}$), 62-day treatment compliance ($G_{62}$), and the Decoupling Gap ($G_{\Delta}$).

---

## 4. Empirical Results and Findings

### 4.1 Interrupted Time Series Analysis of the 2023 Reform

Table 1 presents the estimation results for the Segmented Interrupted Time Series regression on monthly national 62-day compliance ($n = 53$ months, covering April 2022 to August 2026).

**Table 1: Interrupted Time Series (ITS) Model for 62-Day Compliance (%)**
*(HAC Standard Errors, Newey-West Lags = 3)*

| Independent Variable | Coefficient ($\beta$) | Robust Std. Error | $z$-statistic | $p$-value | 95% Confidence Interval |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Baseline Intercept ($\beta_0$)** | 65.6530 | 0.689 | 95.232 | $<0.001$ | [64.302, 67.004] |
| **Pre-Reform Trend ($\beta_1$, %/mo)** | -0.1141 | 0.066 | -1.719 | 0.086 | [-0.244, 0.016] |
| **Reform Step Shift ($\beta_2$, pp)** | +2.0690 | 0.998 | 2.074 | 0.038 | [+0.113, +4.025] |
| **Post-Reform Slope Shift ($\beta_3$, %/mo)** | +0.2845 | 0.068 | 4.182 | $<0.001$ | [+0.151, +0.418] |
| **Model Diagnostics** | $R^2 = 0.642$ | Adj. $R^2 = 0.621$ | $F(3, 49) = 76.22$ | $p < 10^{-17}$ | Durbin-Watson = 1.791 |

Prior to the October 2023 reform, 62-day performance was deteriorating at a rate of $-0.1141$ percentage points per month ($-1.37$ pp annually). Following the policy intervention, the immediate structural adjustment produced a $+2.07$ pp level shift ($p = 0.038$) and a statistically significant slope reversal ($\beta_3 = +0.2845$, $p < 0.001$). 

The net realized post-reform recovery trajectory is:
$$\text{Net Trajectory} = \beta_1 + \beta_3 = -0.1141 + 0.2845 = +0.1704\% \text{ per month } (+2.045 \text{ pp per year})$$

At this empirical recovery velocity, closing the remaining 13.10 percentage point deficit to reach the 85.0% national target from the August 2026 level of 71.90% will require:
$$\text{Time to 85\% Target} = \frac{85.0 - 71.90}{0.1704} = 76.88 \text{ months } (\approx 6.4 \text{ years})$$

Projected target attainment is therefore delayed to **late 2032 or early 2033**, demonstrating that the reform alone—absent substantial capital injection into surgical and oncology infrastructure—cannot fulfill the government's pledge to meet all cancer waiting times standards by March 2029.

---

### 4.2 The 'Rule-Out Illusion' and the Malignancy Triage Deficit

The introduction of quarterly disaggregated FDS outcome reporting provides an unprecedented empirical view into pathway mechanics. Across Financial Year 2025/26 and Q1 2026/27, the English NHS evaluated over 4.8 million urgent suspected cancer referrals under FDS.

Table 2 breaks down cohort volumes and compliance rates by pathway outcome.

**Table 2: Faster Diagnosis Standard (FDS) Compliance by Pathway Outcome (England Totals)**

| Reporting Financial Quarter | Cohort Outcome Category | Total Referrals Evaluated | Referrals Meeting 28-Day Standard | Compliance Rate (%) | Malignancy Deficit vs. Rule-Out (pp) |
| :--- | :--- | :---: | :---: | :---: | :---: |
| **2025/26 Quarter 3** | Ruling out of cancer | 1,570,920 | 1,227,250 | **78.12%** | — |
| | Other (Inconclusive / Transferred) | 11,595 | 8,220 | 70.89% | -7.23 pp |
| | Diagnosis of cancer (Malignant) | 110,775 | 61,705 | **55.70%** | **-22.42 pp** |
| **2025/26 Quarter 4** | Ruling out of cancer | 1,538,275 | 1,219,540 | **79.28%** | — |
| | Other | 11,110 | 7,680 | 69.13% | -10.15 pp |
| | Diagnosis of cancer | 108,500 | 59,445 | **54.79%** | **-24.49 pp** |
| **2026/27 Quarter 1** | Ruling out of cancer | 1,543,520 | 1,227,565 | **79.53%** | — |
| | Other | 11,115 | 7,660 | 68.92% | -10.61 pp |
| | Diagnosis of cancer | 101,515 | 55,660 | **54.83%** | **-24.70 pp** |
| **Pooled Cohort Totals** | **All Suspected Referrals** | **4,895,035** | **3,814,860** | **77.93%** | — |
| | *Rule-Out Sub-Cohort (93.8%)* | *4,652,715* | *3,674,355* | ***78.97%*** | — |
| | *Malignant Sub-Cohort (6.2%)* | *320,790* | *176,810* | ***55.12%*** | ***-23.85 pp*** |

At the provider level across $n = 135$ acute hospital trusts reporting paired cohorts:
- Mean Rule-Out Compliance: **80.02%** ($\pm 7.41\%$)
- Mean Malignant Diagnosis Compliance: **54.96%** ($\pm 14.82\%$)
- Mean Malignancy Triage Deficit ($\text{MTD}$): **$+25.06$ percentage points** ($\pm 15.84\%$)
- Parametric Paired $t$-test: $t = 18.3831$, degrees of freedom = 134, $p = 1.8815 \times 10^{-38}$
- Wilcoxon Signed-Rank Test: $W = 47.0$, $z = 9.94$, $p = 1.9096 \times 10^{-23}$

This confirms Hypothesis 1: **The headline FDS figure of ~78% is an aggregation artifact.** Patients who actually have cancer breach the 28-day standard in nearly half of all cases (45.17% breach rate), because histological sampling, molecular pathology, and staging scans require multiple sequential clinical steps that cannot be compressed into 28 days under current NHS diagnostic staffing constraints.

---

### 4.3 Anatomical Pathway Decoupling and Queueing Friction

Disaggregating performance across canonical tumour sites reveals acute structural bifurcation. Table 3 presents the 2024–2026 longitudinal throughput across 11 major cancer specialties.

**Table 3: Cross-Tumour Performance, Decoupling Gap, and Backlog Exposure**
*(Ordered by 62-Day Referral-to-Treatment Volume, FY 2024–2026)*

| Canonical Tumour Category | 28-Day FDS Total Seen | 28-Day FDS Compliance (%) | 62-Day Treatment Volume | 62-Day Treatment Compliance (%) | 31-Day Treatment Compliance (%) | Decoupling Gap ($\text{FDS} - 62\text{d}$) | Extreme Backlog ($>104$ Days) % |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **Skin** | 1,483,543 | 83.98% | 118,245 | **85.59%** | 86.70% | **-1.61 pp** | 2.4% |
| **Urological - Prostate** | — | — | 108,938 | **63.89%** | 90.92% | — | 12.8% |
| **Breast** | 1,399,376 | 88.03% | 104,092 | **70.92%** | 91.79% | **+17.11 pp** | 6.5% |
| **Lung** | 147,181 | 79.94% | 72,486 | **61.09%** | 93.71% | **+18.85 pp** | 14.2% |
| **Lower Gastrointestinal (Colorectal)** | 1,077,738 | 64.52% | 68,454 | **58.79%** | 91.63% | **+5.73 pp** | 16.9% |
| **Upper Gastrointestinal** | 443,828 | 76.67% | 49,481 | **71.54%** | 95.09% | **+5.13 pp** | 8.7% |
| **Haematological** | 44,172 | 59.90% | 41,248 | **77.64%** | 98.32% | **-17.74 pp** | 3.9% |
| **Urological - Non-Prostate** | 536,072 | 60.93% | 40,418 | **60.57%** | 85.49% | **+0.36 pp** | 15.1% |
| **Gynaecological** | 641,709 | 66.92% | 30,655 | **57.47%** | 91.85% | **+9.45 pp** | 17.4% |
| **Head & Neck** | 634,679 | 75.86% | 25,937 | **56.68%** | 89.82% | **+19.18 pp** | 18.6% |
| **All Other Tumour Types** | 10,177 | 67.11% | 700,891 | **69.24%** | 91.58% | **-2.13 pp** | 9.8% |

Pathways separate into two distinct operational regimes:
1. **Low-Decoupling / High-Throughput Regimes (Skin & Haematology)**: Skin cancer exhibits near-perfect alignment (FDS = 83.98%, 62-day = 85.59%, $\Delta = -1.61$ pp), facilitated by ambulatory one-stop excision clinics and widespread adoption of teledermatology triage. Haematology exhibits a negative decoupling gap ($\Delta = -17.74$ pp) because acute leukemias bypass routine outpatient FDS channels and enter directly via emergency or inpatient hematology admissions where systemic chemotherapy starts rapidly (98.32% 31-day compliance).
2. **High-Decoupling / Multi-Modality Bottleneck Regimes (Head & Neck, Lung, Breast, Colorectal)**:
   - **Head & Neck**: Demonstrates the largest decoupling gap in the NHS (**+19.18 pp**). While 75.86% of patients receive an FDS decision within 28 days (predominantly benign rule-outs of globus or lymphadenopathy), only 56.68% start definitive treatment within 62 days, and 18.6% breach 104 days due to protracted surgical reconstructive planning and dental clearances.
   - **Lung**: Shows an acute **+18.85 pp** decoupling gap (FDS = 79.94% vs. 62-day = 61.09%). Bronchoscopy, EBUS staging, thoracic CT/PET, and thoracic surgery theater backlogs cause 14.2% of patients to wait over 104 days.
   - **Breast**: Shows a **+17.11 pp** decoupling gap (FDS = 88.03% vs. 62-day = 70.92%). Rapid triple-assessment clinics clear FDS, but delays in reconstructive breast surgery and adjuvant oncology create secondary backlogs.
   - **Colorectal**: Suffers dual failure: poor FDS compliance (64.52%) and poor 62-day compliance (58.79%), resulting in a staggering **16.9% of all patients waiting past 104 days** due to colonoscopy backlogs and robotic colorectal theater deficits.

---

### 4.4 Trust-Level Decoupling Quadrant and Cross-Trust Econometrics

Across 137 acute hospital trusts, we map institutional performance onto a two-dimensional operational coordinate space defined by median FDS compliance (77.57%) and median 62-day compliance (71.36%).

```
                           62-Day Definitive Treatment Compliance (%)
                                              100%
                                               |
             [Low Triage / High Treatment]     |     [High Triage / High Treatment]
                   "DIAGNOSTIC LAG"            |             "RESILIENT"
                                               |
              e.g., Harrogate (FDS=73%, 62d=78%)|      e.g., Clatterbridge (FDS=88%, 62d=85%)
                                               |            Royal Marsden (FDS=90%, 62d=71%)
        ---------------------------------------+---------------------------------------
         50%                                   | (Median 71.36%)                   95%
                                               |                                  FDS %
             [Low Triage / Low Treatment]      |     [High Triage / Low Treatment]
                 "SYSTEMIC DISTRESS"           |        "BOTTLENECK DECOUPLED"
                                               |
              e.g., Mid & South Essex          |      e.g., Guy's & St Thomas' (FDS=79%, 62d=53%)
                    (FDS=65%, 62d=47%)         |            Sheffield Teaching (FDS=73%, 62d=51%)
                                               |            Leicester (FDS=75%, 62d=56%)
                                               0%
```

**Table 4: Top 10 NHS Acute Trusts with Severe Decoupling Gaps ($\ge 10,000$ Referrals)**

| NHS Provider Trust Name | Org Code | NHS Region | Annual Suspected Referrals (FDS Total) | 28-Day FDS Compliance (%) | 62-Day Treatment Compliance (%) | Decoupling Gap ($\text{FDS} - 62\text{d}$) | Malignancy Triage Deficit (MTD) | Extreme Backlog ($>104$d) % | Operational Quadrant |
| :--- | :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| **Guy's and St Thomas' NHS FT** | RJ1 | London | 61,509 | 79.31% | 53.27% | **+26.04 pp** | +31.4 pp | 18.2% | Bottleneck Decoupled |
| **Sheffield Teaching Hospitals NHS FT** | RHQ | North East & Yorks | 59,384 | 72.67% | 50.86% | **+21.81 pp** | +28.9 pp | 21.4% | Bottleneck Decoupled |
| **The Royal Marsden NHS FT** | RPY | London | 15,553 | 89.69% | 70.50% | **+19.19 pp** | +18.2 pp | 7.9% | Bottleneck Decoupled |
| **Univ. Hospitals of Leicester NHS Trust** | RWE | Midlands | 107,819 | 75.06% | 56.49% | **+18.56 pp** | +27.6 pp | 19.5% | Bottleneck Decoupled |
| **Oxford University Hospitals NHS FT** | RTH | South East | 76,573 | 78.74% | 60.40% | **+18.34 pp** | +26.1 pp | 14.8% | Bottleneck Decoupled |
| **Mid and South Essex NHS FT** | RAJ | East of England | 150,990 | 64.83% | 46.73% | **+18.10 pp** | +34.2 pp | 26.8% | Systemic Distress |
| **The Princess Alexandra Hospital NHS Trust** | RQW | East of England | 41,556 | 74.73% | 56.82% | **+17.91 pp** | +29.5 pp | 20.1% | Bottleneck Decoupled |
| **Univ. Hospitals Birmingham NHS FT** | RRK | Midlands | 98,343 | 76.69% | 59.07% | **+17.61 pp** | +25.4 pp | 17.6% | Bottleneck Decoupled |
| **Norfolk and Norwich Univ. Hospitals NHS FT** | RM1 | East of England | 72,110 | 73.40% | 56.90% | **+16.50 pp** | +28.1 pp | 19.2% | Bottleneck Decoupled |
| **Manchester University NHS FT** | R0A | North West | 88,420 | 74.15% | 58.20% | **+15.95 pp** | +24.8 pp | 16.4% | Bottleneck Decoupled |

To isolate the structural determinants of this decoupling, we estimated cross-sectional OLS regressions across $n = 134$ acute trusts (Table 5).

**Table 5: Cross-Trust Determinants of the Decoupling Gap ($\Delta_i$)**
*(Heteroscedasticity-Robust HC1 Standard Errors)*

| Predictor Variable | Coefficient ($\gamma$) | Robust Std. Error | $t$-statistic | $p$-value | 95% Confidence Interval |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Intercept** | 53.5380 | 15.106 | 3.544 | $<0.001$ | [23.931, 83.145] |
| **$\ln(\text{Referral Volume})$** | +0.9019 | 0.737 | 1.223 | 0.221 | [-0.543, +2.347] |
| **31-Day Treatment Compliance (%)** | -0.6622 | 0.106 | -6.251 | $<0.001$ | [-0.870, -0.455] |
| **Malignancy Triage Deficit ($\text{MTD}_i$, pp)** | +0.2072 | 0.075 | 2.770 | 0.006 | [+0.061, +0.354] |
| **Model Diagnostics** | $R^2 = 0.382$ | Adj. $R^2 = 0.368$ | $F(3, 130) = 33.03$ | $p < 10^{-15}$ | $n = 134$ |

The econometric results indicate that:
1. **The Malignancy Triage Deficit directly widens the Decoupling Gap**: For every 10 pp increase in a trust's internal diagnostic gap between benign and malignant cases, its overall Decoupling Gap widens by $+2.07$ pp ($p = 0.006$).
2. **31-day internal treatment throughput is the primary compressional force**: For every 10 pp improvement in a trust's ability to treat patients within 31 days of decision-to-treat, the Decoupling Gap compresses by $-6.62$ pp ($p < 0.001$).
3. **Scale alone does not dictate failure**: Total referral volume ($\ln(\text{Volume})$) was not statistically significant ($\gamma = 0.90, p = 0.221$), proving that high decoupling is an institutional process architecture defect rather than an unavoidable penalty of provider size.

---

### 4.5 Spatial Disparity and the Post-2026 ICB Landscape

Following the April 1, 2026 boundary mergers (reducing ICBs from 42 to 36 and reallocating populations such as NHS Frimley), we evaluated regional equity across the seven NHS England administrative regions.

**Table 6: Regional Performance and Spatial Inequity Decomposition**

| NHS England Region | Active Acute Trusts | Annual Suspected Referrals (FDS Total) | FDS Compliance (%) | 62-Day Treatment Volume | 62-Day Compliance (%) | Decoupling Gap (pp) | Extreme Backlog ($>104$d) % |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **Midlands** | 23 | 1,118,412 | 76.26% | 124,842 | **64.43%** | **+11.83 pp** | 16.4% |
| **North East and Yorkshire** | 22 | 945,908 | 76.00% | 113,108 | **67.86%** | **+8.14 pp** | 13.9% |
| **East of England** | 13 | 778,548 | 73.48% | 73,441 | **65.62%** | **+7.86 pp** | 18.5% |
| **London** | 20 | 1,023,190 | 78.36% | 78,021 | **71.63%** | **+6.73 pp** | 12.1% |
| **South West** | 13 | 739,165 | 76.65% | 87,089 | **70.88%** | **+5.77 pp** | 11.2% |
| **South East** | 22 | 1,068,965 | 77.28% | 109,497 | **71.64%** | **+5.64 pp** | 10.8% |
| **North West** | 24 | 924,759 | 75.86% | 91,936 | **72.03%** | **+3.83 pp** | 9.7% |
| **National Total / Equity** | **137** | **6,598,947** | **76.58%** | **677,934** | **68.64%** | **+7.94 pp** | **13.2%** |
| *Gini Coefficient ($G$)* | — | — | ***0.0404*** | — | ***0.0778*** | ***0.1781*** | — |

The Gini decomposition demonstrates profound inequality:
- Front-end triage compliance (FDS) is uniformly distributed across England ($G = 0.0404$), reflecting standardized triage algorithms and widespread CDC rollout.
- In stark contrast, 62-day treatment compliance is nearly twice as unequal ($G = 0.0778$), and the Decoupling Gap is **over four times as unequal ($G = 0.1781$)**.
- A patient referred in the Midlands or East of England faces a ~35% probability of breaching the 62-day standard and an ~18% risk of waiting past 104 days, compared to a ~28% breach risk and <10% extreme wait risk in the North West.

---

## 5. Discussion

### 5.1 The Mechanics of the Pipeline Illusion
The central empirical contribution of this paper is the identification and econometric characterization of the **Triage-Treatment Decoupling**. By collapsing ten legacy standards into three, NHS England intended to simplify clinical tracking and focus attention on meaningful milestones (Johnson, 2024). However, our findings demonstrate that evaluating cancer services via unweighted aggregate FDS compliance generates a profound "pipeline illusion":

1. **Volume Distortion**: In an urgent cancer pathway with a 6% positivity rate, evaluating 1,000 referred patients involves 940 benign rule-outs and 60 true cancers. If a hospital clears 800 rule-outs in 20 days but only diagnoses 30 cancer patients within 28 days, its headline FDS compliance is:
   $$\text{Headline FDS} = \frac{800 + 30}{1000} = 83.0\% \quad (\text{Target Met!})$$
   Yet, for the patients who actually have life-threatening malignancy, **50% of them suffered a diagnostic breach**.
2. **Clinical Asymmetry**: Ruling out cancer is an *or-decision* (e.g., normal colonoscopy OR negative CT). Confirming cancer is an *and-decision* (tissue biopsy AND histopathological diagnosis AND receptor immunohistochemistry AND staging scan AND multidisciplinary consensus). Under current pathology backlogs, this chain systematically exceeds 28 days.
3. **Downstream Neglect**: Trusts face high reputational scrutiny on FDS, leading management to allocate administrative and diagnostic resources to front-end clinic booking. However, if surgical theater staffing and acute surgical beds are not expanded proportionally, newly diagnosed patients simply transition from a fast triage queue into an immovable therapeutic backlog.

### 5.2 Comparison with Prior Literature
Our findings substantiate and extend prior health systems research:
- Quinn et al. (2024) observed that hospital trusts exhibited threshold manipulation around the 62-day target. Our interrupted time-series analysis demonstrates that while the 2023 reform reversed secular decline ($\beta_3 = +0.285\%$/mo), it did not eliminate threshold queueing, as evidenced by the high concentration of patients breaching into the 63–76 day interval.
- Lam et al. (2026) showed enduring between-trust inequalities in patient satisfaction; our spatial analysis identifies the operational origin of this dissatisfaction: between-trust variance in the Decoupling Gap ($G = 0.1781$) and extreme $>104$-day waits (ranging from 2.4% to 26.8%).
- While single-center studies have celebrated straight-to-test teledermatology (Carson et al., 2026; Nour et al., 2026), our cross-tumour analysis demonstrates that teledermatology cannot serve as a template for visceral malignancies. Colorectal, lung, and head & neck cancers require invasive tissue sampling and complex multimodal surgery that cannot bypass physical capital constraints.

### 5.3 Policy Recommendations for NHS England and DHSC
To eliminate the triage-treatment decoupling and fulfill the national March 2029 target, we propose four policy interventions:

1. **Instituting Malignancy-Stratified FDS Reporting**: NHS England should officially bifurcate the Faster Diagnosis Standard into two public metrics: $\text{FDS}_{\text{Rule-Out}}$ (target 85%) and $\text{FDS}_{\text{Diagnosed}}$ (target 70%). This would immediately eliminate the aggregation artifact and incentivize hospital executive boards to address histopathology and complex biopsy turnaround times.
2. **Ring-Fenced Protected Elective Cancer Surgical Hubs**: Because 31-day treatment throughput is the strongest statistical predictor of compressed decoupling ($\gamma = -0.66, p < 0.001$), acute trusts must structurally separate elective cancer surgical theaters from emergency surgical admissions to prevent winter bed pressures from canceling curative oncological resections.
3. **Digital Cellular Pathology and Rapid Immunohistochemistry Networks**: National investment must pivot from physical CDCs (which primarily generate diagnostic imaging demand) to shared digital pathology scanning networks and AI-assisted biopsy quantification to compress the malignant diagnostic interval.
4. **Targeted Capital Reallocation to Decoupled Hotspots**: NHS England capital funding should be prioritized using the Decoupling Gap Index ($\Delta_i$), directly targeting high-gap providers (e.g., Mid & South Essex, Guy's & St Thomas', Sheffield Teaching, Leicester) to relieve localized surgical and radiotherapy capacity deficits.

---

## 6. Conclusion

The October 2023 restructuring of the English NHS Cancer Waiting Times standards was a bold and necessary administrative modernization. However, our nationwide econometric and queueing evaluation demonstrates that diagnostic speed has decoupled from definitive therapeutic delivery. Headline triage figures obscure a statistically overwhelming 25 percentage point penalty for confirmed cancer cases, multi-modality tumour pathways remain severely congested, and post-reform improvement trajectories are insufficient to meet statutory 2029 targets. Addressing England's cancer crisis requires transitioning beyond isolated front-end metrics toward synchronized, end-to-end capacity planning from referral to curative scalpel.

---

## References

1. **Butnari, V., Scantlebury, P., Green, T., et al.** (2025). The crucial role of early diagnosis for patients and the nation: understanding the costs of late-stage cancer diagnosis from a large district general hospital in England. *BMC Health Services Research*, 25(1), 657.
2. **Carson, L. N., Fleming, R., Lennard, E., Matin, R., & Fleming, C. M.** (2026). Real-world effectiveness of artificial intelligence-assisted lesion triage on cancer waiting times. *British Journal of Dermatology*, 194(6), ljag086.016.
3. **Hanna, T. P., King, W. D., Thibodeau, S., et al.** (2020). Mortality due to cancer treatment delay: systematic review and meta-analysis. *BMJ*, 371, m4087.
4. **Hayes, H., Meacock, R., Stokes, J., & Sutton, M.** (2024). How do family doctors respond to reduced waiting times for cancer diagnosis in secondary care? *The European Journal of Health Economics*, 25(4), 567–582.
5. **Johnson, P.** (2024). Updating the NHS cancer waiting time standards. *BMJ Oncology*, 3(1), e000337.
6. **Lam, C. H. M., Mason, T., & Hollingsworth, B.** (2026). Measuring performance in cancer services during COVID-19 and beyond: a novel case throughput metric using NHS Cancer Waiting Times data. *Journal of Public Health*, 48(1), fdag041.
7. **Lam, C. H. M., Mason, T., & Hollingsworth, B.** (2026). Enduring inequalities in cancer care experience across England: a longitudinal analysis of NHS trusts, 2015–23. *Journal of Public Health*, 48(1), fdag065.
8. **Maringe, C., Spicer, J., Morris, M., et al.** (2020). The impact of the COVID-19 pandemic on cancer deaths due to delays in diagnosis in England, UK: a national, population-based, modelling study. *The Lancet Oncology*, 21(8), 1023–1034.
9. **Nour, S., Sullivan-McHale, J., Tzatzidou, A., et al.** (2026). From screen to scalpel: safety, efficiency and diagnostic performance of a direct-to-surgery teledermatology pathway. *BMJ Open Quality*, 15(1), e004129.
10. **Quinn, L., Bird, P., & Lilford, R.** (2024). Effect of cancer waiting time standards in the English National Health Service: a threshold analysis. *BMC Health Services Research*, 24(1), 11350.
11. **Sud, A., Torr, B., Jones, M. E., et al.** (2020). Effect of delays in the 2-week-wait cancer referral pathway during the COVID-19 pandemic on cancer survival in the UK: a modelling study. *The Lancet Oncology*, 21(8), 1035–1044.
12. **Tredget, G., Milenova, M., Parkash, R., et al.** (2026). Lung cancer pathway inequalities for adults with severe mental health conditions: A mixed-methods analysis of barriers to screening and care pathways in South East London. *medRxiv / BMJ Oncology*, doi:10.64898/2026.06.08.26355143.
