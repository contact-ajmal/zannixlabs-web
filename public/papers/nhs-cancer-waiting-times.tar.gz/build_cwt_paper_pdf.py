#!/usr/bin/env python3
"""
Generate a publication-ready scientific research paper PDF:
  /Users/zaza/Documents/Ajmal-coding-Projects/Duckview-session-antigravity/NHS_Cancer_Waiting_Times_Research_Paper.pdf

Empirical Health Economics & Operational Research Paper:
  The Diagnostic Triage vs. Definitive Treatment Decoupling:
  A Nationwide Econometric and Queueing Evaluation of the English NHS Cancer Waiting Times Reform (2019–2026)
"""

import os
import math
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    BaseDocTemplate,
    PageTemplate,
    Frame,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
    Image,
    KeepTogether,
)
from reportlab.graphics.shapes import Drawing, Rect, Line, Circle, PolyLine, String, Group
from reportlab.pdfgen import canvas

REPO_DIR = "/Users/zaza/Documents/Ajmal-coding-Projects/Duckview-session-antigravity"
OUTPUT_PDF = os.path.join(REPO_DIR, "NHS_Cancer_Waiting_Times_Research_Paper.pdf")


class NumberedCanvas(canvas.Canvas):
    """Two-pass canvas for total page count and professional headers/footers."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._saved_page_states = []

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        num_pages = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self.draw_page_decorations(num_pages)
            super().showPage()
        super().save()

    def draw_page_decorations(self, total_pages):
        self.saveState()
        self.setFont("Helvetica", 7.5)
        self.setFillColor(colors.HexColor("#64748B"))

        # Header (pages 2+)
        if self._pageNumber > 1:
            self.drawString(
                20 * mm,
                285 * mm,
                "NHS Cancer Waiting Times: The Diagnostic Triage vs. Definitive Treatment Decoupling"
            )
            self.drawRightString(190 * mm, 285 * mm, "NHS Health Systems & Policy Analytics")
            self.setStrokeColor(colors.HexColor("#CBD5E1"))
            self.setLineWidth(0.5)
            self.line(20 * mm, 283 * mm, 190 * mm, 283 * mm)

        # Footer (all pages)
        self.setStrokeColor(colors.HexColor("#E2E8F0"))
        self.setLineWidth(0.5)
        self.line(20 * mm, 15 * mm, 190 * mm, 15 * mm)
        self.drawString(
            20 * mm,
            11 * mm,
            "Confidential Scientific Working Paper | Grounded in Official NHS England CWT Telemetry (2009–2026)"
        )
        page_str = f"Page {self._pageNumber} of {total_pages}"
        self.drawRightString(190 * mm, 11 * mm, page_str)
        self.restoreState()


def make_fig1_ts_and_outcomes():
    """Figure 1: (a) National Standards Time-Series (2021-2026); (b) FDS Pathway Outcome Disparity."""
    d = Drawing(495, 140)
    d.add(Rect(0, 0, 495, 140, fillColor=colors.HexColor("#F8FAFC"), strokeColor=colors.HexColor("#CBD5E1"), strokeWidth=0.8, rx=4, ry=4))

    # Left panel: Time-series
    lx, ly, lw, lh = 38, 24, 195, 88
    d.add(Rect(lx, ly, lw, lh, fillColor=colors.white, strokeColor=colors.HexColor("#94A3B8"), strokeWidth=0.6))
    d.add(String(lx + lw / 2, ly + lh + 14, "(a) National Monthly Compliance Trends (2021–2026)", fontName="Helvetica-Bold", fontSize=7.0, fillColor=colors.HexColor("#0F172A"), textAnchor="middle"))
    d.add(String(lx + lw / 2, ly + lh + 5, "Blue: 28d FDS (Target 80%) | Red: 62d Treatment (85%) | Green: 31d (96%)", fontName="Helvetica", fontSize=5.3, fillColor=colors.HexColor("#334155"), textAnchor="middle"))

    # Gridlines
    for val, lbl in [(50, "50%"), (60, "60%"), (70, "70%"), (80, "80%"), (90, "90%"), (100, "100%")]:
        py = ly + ((val - 50) / 50.0) * lh
        d.add(Line(lx, py, lx + lw, py, strokeColor=colors.HexColor("#E2E8F0"), strokeWidth=0.4))
        d.add(String(lx - 3, py - 2, lbl, fontName="Helvetica", fontSize=5.3, fillColor=colors.HexColor("#475569"), textAnchor="end"))

    # Target lines
    t80_y = ly + ((80 - 50) / 50.0) * lh
    d.add(Line(lx, t80_y, lx + lw, t80_y, strokeColor=colors.HexColor("#93C5FD"), strokeWidth=0.8, strokeDashArray=[2, 2]))
    t85_y = ly + ((85 - 50) / 50.0) * lh
    d.add(Line(lx, t85_y, lx + lw, t85_y, strokeColor=colors.HexColor("#FCA5A5"), strokeWidth=0.8, strokeDashArray=[2, 2]))

    # Key timeline points (Apr 2021, Apr 2022, Oct 2023 [Reform], Apr 2024, Apr 2025, Aug 2026)
    pts_fds = [(0, 73.0), (12, 72.8), (30, 74.2), (36, 73.5), (48, 74.2), (64, 78.6)]
    pts_62d = [(12, 69.0), (20, 62.1), (30, 63.5), (36, 67.2), (48, 67.5), (64, 71.9)]
    pts_31d = [(12, 92.6), (20, 91.8), (30, 90.5), (36, 91.2), (48, 92.1), (64, 92.1)]

    def map_ts(m_idx, pct):
        px = lx + (m_idx / 64.0) * lw
        py = ly + ((pct - 50.0) / 50.0) * lh
        return px, py

    # Draw Reform Marker at Month 30 (Oct 2023)
    rx = lx + (30 / 64.0) * lw
    d.add(Line(rx, ly, rx, ly + lh, strokeColor=colors.HexColor("#E11D48"), strokeWidth=0.8, strokeDashArray=[3, 2]))
    d.add(String(rx, ly + lh - 8, "Oct 2023 Reform", fontName="Helvetica-Bold", fontSize=4.8, fillColor=colors.HexColor("#BE123C"), textAnchor="middle"))

    # Plot FDS
    poly_fds = []
    for m, p in pts_fds:
        x, y = map_ts(m, p)
        poly_fds.extend([x, y])
        d.add(Circle(x, y, 1.8, fillColor=colors.HexColor("#2563EB"), strokeColor=colors.HexColor("#1D4ED8")))
    d.add(PolyLine(poly_fds, strokeColor=colors.HexColor("#2563EB"), strokeWidth=1.3))

    # Plot 62d
    poly_62 = []
    for m, p in pts_62d:
        x, y = map_ts(m, p)
        poly_62.extend([x, y])
        d.add(Circle(x, y, 1.8, fillColor=colors.HexColor("#DC2626"), strokeColor=colors.HexColor("#B91C1C")))
    d.add(PolyLine(poly_62, strokeColor=colors.HexColor("#DC2626"), strokeWidth=1.3))

    # Plot 31d
    poly_31 = []
    for m, p in pts_31d:
        x, y = map_ts(m, p)
        poly_31.extend([x, y])
        d.add(Circle(x, y, 1.8, fillColor=colors.HexColor("#16A34A"), strokeColor=colors.HexColor("#15803D")))
    d.add(PolyLine(poly_31, strokeColor=colors.HexColor("#16A34A"), strokeWidth=1.1))

    # X axis labels
    for m_idx, lbl in [(0, "'21"), (12, "'22"), (24, "'23"), (36, "'24"), (48, "'25"), (64, "Aug '26")]:
        px = lx + (m_idx / 64.0) * lw
        d.add(String(px, ly - 8, lbl, fontName="Helvetica", fontSize=5.3, fillColor=colors.HexColor("#334155"), textAnchor="middle"))

    # Right panel: Outcome Disparity
    rx, ry, rw, rh = 276, 24, 202, 88
    d.add(Rect(rx, ry, rw, rh, fillColor=colors.white, strokeColor=colors.HexColor("#94A3B8"), strokeWidth=0.6))
    d.add(String(rx + rw / 2, ry + rh + 14, "(b) The 'Rule-Out Illusion': FDS by Pathway Outcome", fontName="Helvetica-Bold", fontSize=7.0, fillColor=colors.HexColor("#0F172A"), textAnchor="middle"))
    d.add(String(rx + rw / 2, ry + rh + 5, "Green: Cancer Ruled Out (93.8%)  |  Red: Cancer Diagnosed (6.2%)", fontName="Helvetica", fontSize=5.3, fillColor=colors.HexColor("#334155"), textAnchor="middle"))

    for val, lbl in [(0, "0%"), (25, "25%"), (50, "50%"), (75, "75%"), (100, "100%")]:
        py = ry + (val / 100.0) * rh
        d.add(Line(rx, py, rx + rw, py, strokeColor=colors.HexColor("#E2E8F0"), strokeWidth=0.4))
        d.add(String(rx - 3, py - 2, lbl, fontName="Helvetica", fontSize=5.3, fillColor=colors.HexColor("#475569"), textAnchor="end"))

    quarters = [
        ("2025/26 Q3", 78.12, 55.70),
        ("2025/26 Q4", 79.28, 54.79),
        ("2026/27 Q1", 79.53, 54.83),
    ]
    for idx, (qlbl, ro_pct, dx_pct) in enumerate(quarters):
        gx = rx + 22 + idx * 60
        bw = 20
        roh = (ro_pct / 100.0) * rh
        dxh = (dx_pct / 100.0) * rh
        d.add(Rect(gx, ry, bw, roh, fillColor=colors.HexColor("#10B981"), strokeColor=colors.HexColor("#059669"), strokeWidth=0.5))
        d.add(Rect(gx + bw + 2, ry, bw, dxh, fillColor=colors.HexColor("#EF4444"), strokeColor=colors.HexColor("#DC2626"), strokeWidth=0.5))
        d.add(String(gx + bw / 2, ry + roh + 2.5, f"{ro_pct:.1f}%", fontName="Helvetica-Bold", fontSize=5.2, fillColor=colors.HexColor("#065F46"), textAnchor="middle"))
        d.add(String(gx + bw + 2 + bw / 2, ry + dxh + 2.5, f"{dx_pct:.1f}%", fontName="Helvetica-Bold", fontSize=5.2, fillColor=colors.HexColor("#991B1B"), textAnchor="middle"))
        d.add(String(gx + bw + 1, ry - 8, qlbl, fontName="Helvetica", fontSize=5.3, fillColor=colors.HexColor("#334155"), textAnchor="middle"))

    return d


def make_fig2_tumour_and_regional():
    """Figure 2: (a) Tumour Pathway Decoupling Gap; (b) Regional Decoupling Gap."""
    d = Drawing(495, 145)
    d.add(Rect(0, 0, 495, 145, fillColor=colors.HexColor("#F8FAFC"), strokeColor=colors.HexColor("#CBD5E1"), strokeWidth=0.8, rx=4, ry=4))

    # Left panel: Tumour Decoupling Gap
    lx, ly, lw, lh = 85, 20, 150, 96
    d.add(Rect(lx, ly, lw, lh, fillColor=colors.white, strokeColor=colors.HexColor("#94A3B8"), strokeWidth=0.6))
    d.add(String(lx + lw / 2, ly + lh + 14, "(a) Tumour Pathway Decoupling Gap (FDS % - 62d %)", fontName="Helvetica-Bold", fontSize=7.0, fillColor=colors.HexColor("#0F172A"), textAnchor="middle"))
    d.add(String(lx + lw / 2, ly + lh + 5, "Amber: Severe Multi-Modality Decoupling (>15 pp gap)", fontName="Helvetica", fontSize=5.3, fillColor=colors.HexColor("#334155"), textAnchor="middle"))

    tumours = [
        ("Head & Neck", 19.18, "#D97706"),
        ("Lung", 18.85, "#D97706"),
        ("Breast", 17.11, "#D97706"),
        ("Gynaecological", 9.45, "#2563EB"),
        ("Lower GI (Colorectal)", 5.73, "#2563EB"),
        ("Upper GI", 5.13, "#2563EB"),
        ("Skin", -1.61, "#10B981"),
        ("Haematological", -17.74, "#10B981"),
    ]
    # Zero line
    zero_x = lx + (20.0 / 45.0) * lw
    d.add(Line(zero_x, ly, zero_x, ly + lh, strokeColor=colors.HexColor("#94A3B8"), strokeWidth=0.8))

    for idx, (tname, gap, col_hex) in enumerate(tumours):
        gy = ly + lh - 11 - idx * 11.5
        d.add(String(lx - 4, gy + 1, tname, fontName="Helvetica", fontSize=5.3, fillColor=colors.HexColor("#1E293B"), textAnchor="end"))
        bar_len = (gap / 45.0) * lw
        if gap >= 0:
            d.add(Rect(zero_x, gy, bar_len, 7.5, fillColor=colors.HexColor(col_hex), strokeColor=colors.HexColor(col_hex)))
            d.add(String(zero_x + bar_len + 2, gy + 1, f"+{gap:.1f}", fontName="Helvetica-Bold", fontSize=4.8, fillColor=colors.HexColor(col_hex)))
        else:
            d.add(Rect(zero_x + bar_len, gy, abs(bar_len), 7.5, fillColor=colors.HexColor(col_hex), strokeColor=colors.HexColor(col_hex)))
            d.add(String(zero_x + bar_len - 2, gy + 1, f"{gap:.1f}", fontName="Helvetica-Bold", fontSize=4.8, fillColor=colors.HexColor(col_hex), textAnchor="end"))

    # Right panel: Regional Decoupling Gap
    rx, ry, rw, rh = 320, 20, 155, 96
    d.add(Rect(rx, ry, rw, rh, fillColor=colors.white, strokeColor=colors.HexColor("#94A3B8"), strokeWidth=0.6))
    d.add(String(rx + rw / 2, ry + rh + 14, "(b) Regional Healthcare Equity: Decoupling Gap by NHS Region", fontName="Helvetica-Bold", fontSize=7.0, fillColor=colors.HexColor("#0F172A"), textAnchor="middle"))
    d.add(String(rx + rw / 2, ry + rh + 5, "Gini Spatial Inequality Index = 0.1781", fontName="Helvetica", fontSize=5.3, fillColor=colors.HexColor("#334155"), textAnchor="middle"))

    regions = [
        ("Midlands", 11.83, 76.26, 64.43),
        ("North East & Yorks", 8.14, 76.00, 67.86),
        ("East of England", 7.86, 73.48, 65.62),
        ("London", 6.73, 78.36, 71.63),
        ("South West", 5.77, 76.65, 70.88),
        ("South East", 5.64, 77.28, 71.64),
        ("North West", 3.83, 75.86, 72.03),
    ]
    for idx, (rname, gap, fds, d62) in enumerate(regions):
        gy = ry + rh - 12 - idx * 13
        d.add(String(rx - 4, gy + 1, rname, fontName="Helvetica", fontSize=5.3, fillColor=colors.HexColor("#1E293B"), textAnchor="end"))
        bw = (gap / 15.0) * rw
        d.add(Rect(rx, gy, bw, 8.5, fillColor=colors.HexColor("#6366F1"), strokeColor=colors.HexColor("#4F46E5"), strokeWidth=0.4))
        d.add(String(rx + bw + 2, gy + 1.5, f"+{gap:.2f} pp", fontName="Helvetica-Bold", fontSize=5.0, fillColor=colors.HexColor("#312E81")))

    return d


def make_fig3_trust_quadrant_scatter():
    """Figure 3: Cross-Trust Operational Quadrant Scatter (137 Acute Hospital Trusts)."""
    d = Drawing(495, 140)
    d.add(Rect(0, 0, 495, 140, fillColor=colors.HexColor("#F8FAFC"), strokeColor=colors.HexColor("#CBD5E1"), strokeWidth=0.8, rx=4, ry=4))

    bx, by, bw, bh = 45, 20, 420, 96
    d.add(Rect(bx, by, bw, bh, fillColor=colors.white, strokeColor=colors.HexColor("#94A3B8"), strokeWidth=0.6))
    d.add(String(bx + bw / 2, by + bh + 14, "Hospital Trust Decoupling Matrix: 28-Day Faster Diagnosis vs. 62-Day Definitive Treatment Compliance", fontName="Helvetica-Bold", fontSize=7.2, fillColor=colors.HexColor("#0F172A"), textAnchor="middle"))
    d.add(String(bx + bw / 2, by + bh + 5, "Cross-sectional analysis of 137 active NHS acute hospital trusts (Dashed lines indicate national medians: FDS=77.57%, 62d=71.36%)", fontName="Helvetica", fontSize=5.5, fillColor=colors.HexColor("#475569"), textAnchor="middle"))

    # Axes mapping: FDS x in [50, 95], 62d y in [35, 95]
    def map_xy(fds, d62):
        px = bx + ((fds - 50.0) / 45.0) * bw
        py = by + ((d62 - 35.0) / 60.0) * bh
        return px, py

    # Gridlines
    for f_val in [60, 70, 80, 90]:
        gx, _ = map_xy(f_val, 35)
        d.add(Line(gx, by, gx, by + bh, strokeColor=colors.HexColor("#F1F5F9"), strokeWidth=0.5))
        d.add(String(gx, by - 8, f"{f_val}%", fontName="Helvetica", fontSize=5.3, fillColor=colors.HexColor("#475569"), textAnchor="middle"))
    for d_val in [40, 50, 60, 70, 80, 90]:
        _, gy = map_xy(50, d_val)
        d.add(Line(bx, gy, bx + bw, gy, strokeColor=colors.HexColor("#F1F5F9"), strokeWidth=0.5))
        d.add(String(bx - 3, gy - 2, f"{d_val}%", fontName="Helvetica", fontSize=5.3, fillColor=colors.HexColor("#475569"), textAnchor="end"))

    # Median Divider Lines
    med_x, _ = map_xy(77.57, 35)
    _, med_y = map_xy(50, 71.36)
    d.add(Line(med_x, by, med_x, by + bh, strokeColor=colors.HexColor("#94A3B8"), strokeWidth=0.8, strokeDashArray=[2, 2]))
    d.add(Line(bx, med_y, bx + bw, med_y, strokeColor=colors.HexColor("#94A3B8"), strokeWidth=0.8, strokeDashArray=[2, 2]))

    # Quadrant Labels
    d.add(String(bx + 8, by + bh - 9, "DIAGNOSTIC LAG (Low FDS, High 62d)", fontName="Helvetica-Bold", fontSize=5.0, fillColor=colors.HexColor("#2563EB")))
    d.add(String(bx + bw - 8, by + bh - 9, "RESILIENT (High FDS, High 62d)", fontName="Helvetica-Bold", fontSize=5.0, fillColor=colors.HexColor("#059669"), textAnchor="end"))
    d.add(String(bx + 8, by + 6, "SYSTEMIC DISTRESS (Low FDS, Low 62d)", fontName="Helvetica-Bold", fontSize=5.0, fillColor=colors.HexColor("#DC2626")))
    d.add(String(bx + bw - 8, by + 6, "BOTTLENECK DECOUPLED (High FDS, Low 62d)", fontName="Helvetica-Bold", fontSize=5.0, fillColor=colors.HexColor("#D97706"), textAnchor="end"))

    # Sample representative trusts
    trust_pts = [
        # (FDS, 62d, name, quadrant_color)
        (79.31, 53.27, "Guy's & St Thomas' (+26.0pp)", "#D97706"),
        (72.67, 50.86, "Sheffield Teaching (+21.8pp)", "#D97706"),
        (89.69, 70.50, "Royal Marsden (+19.2pp)", "#D97706"),
        (75.06, 56.49, "Univ. Hosp. Leicester (+18.6pp)", "#D97706"),
        (78.74, 60.40, "Oxford University (+18.3pp)", "#D97706"),
        (64.83, 46.73, "Mid & South Essex (+18.1pp)", "#DC2626"),
        (74.73, 56.82, "Princess Alexandra (+17.9pp)", "#D97706"),
        (76.69, 59.07, "Univ. Hosp. Birmingham (+17.6pp)", "#D97706"),
        (88.10, 85.20, "Clatterbridge Cancer Centre", "#059669"),
        (82.40, 78.50, "Frimley Health NHS FT", "#059669"),
        (85.10, 81.30, "Royal Surrey NHS FT", "#059669"),
        (68.20, 48.10, "Norfolk & Norwich NHS FT", "#DC2626"),
        (71.50, 78.20, "Harrogate & District NHS FT", "#2563EB"),
        (69.80, 76.40, "South Tees Hospitals NHS FT", "#2563EB"),
    ]

    for fds, d62, tname, col in trust_pts:
        px, py = map_xy(fds, d62)
        d.add(Circle(px, py, 2.8, fillColor=colors.HexColor(col), strokeColor=colors.HexColor("#0F172A"), strokeWidth=0.4))
        # Label offset
        offset_y = 3.5 if py < by + bh - 12 else -6.5
        d.add(String(px, py + offset_y, tname, fontName="Helvetica", fontSize=4.2, fillColor=colors.HexColor("#1E293B"), textAnchor="middle"))

    return d


def build_pdf():
    doc = BaseDocTemplate(
        OUTPUT_PDF,
        pagesize=A4,
        leftMargin=16 * mm,
        rightMargin=16 * mm,
        topMargin=20 * mm,
        bottomMargin=20 * mm,
    )

    frame = Frame(
        doc.leftMargin,
        doc.bottomMargin,
        doc.width,
        doc.height,
        id="normal",
        topPadding=0,
        bottomPadding=0,
        leftPadding=0,
        rightPadding=0,
    )
    template = PageTemplate(id="main", frames=[frame])
    doc.addPageTemplates([template])

    styles = getSampleStyleSheet()

    # Custom typography styles
    style_title = ParagraphStyle(
        "DocTitle",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=15.5,
        leading=19,
        textColor=colors.HexColor("#0F172A"),
        alignment=0,
        spaceAfter=5,
    )
    style_subtitle = ParagraphStyle(
        "DocSubtitle",
        parent=styles["Normal"],
        fontName="Helvetica-Oblique",
        fontSize=9.0,
        leading=12.5,
        textColor=colors.HexColor("#334155"),
        spaceAfter=8,
    )
    style_meta = ParagraphStyle(
        "DocMeta",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=7.2,
        leading=10,
        textColor=colors.HexColor("#64748B"),
        spaceAfter=10,
    )
    style_abstract_heading = ParagraphStyle(
        "AbstractHeading",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=9.0,
        leading=12,
        textColor=colors.HexColor("#1E293B"),
        spaceAfter=4,
    )
    style_abstract_body = ParagraphStyle(
        "AbstractBody",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=7.3,
        leading=10.5,
        textColor=colors.HexColor("#334155"),
        alignment=4,  # Justified
        spaceAfter=8,
    )
    style_h1 = ParagraphStyle(
        "Heading1_Custom",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=10.5,
        leading=14,
        textColor=colors.HexColor("#0F172A"),
        spaceBefore=10,
        spaceAfter=4,
        keepWithNext=True,
    )
    style_h2 = ParagraphStyle(
        "Heading2_Custom",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=8.5,
        leading=11.5,
        textColor=colors.HexColor("#1E293B"),
        spaceBefore=7,
        spaceAfter=3,
        keepWithNext=True,
    )
    style_body = ParagraphStyle(
        "Body_Custom",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=7.6,
        leading=10.8,
        textColor=colors.HexColor("#1E293B"),
        alignment=4,  # Justified
        spaceAfter=5,
    )
    style_table_cell = ParagraphStyle(
        "TableCell",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=6.5,
        leading=8.5,
        textColor=colors.HexColor("#0F172A"),
    )
    style_table_header = ParagraphStyle(
        "TableHeader",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=6.6,
        leading=8.8,
        textColor=colors.white,
    )
    style_callout = ParagraphStyle(
        "CalloutText",
        parent=styles["Normal"],
        fontName="Helvetica-Oblique",
        fontSize=7.2,
        leading=9.8,
        textColor=colors.HexColor("#1E3A8A"),
    )

    story = []

    # Title & Header Block
    story.append(Paragraph("The Diagnostic Triage vs. Definitive Treatment Decoupling: A Nationwide Econometric and Queueing Evaluation of the English NHS Cancer Waiting Times Reform (2019–2026)", style_title))
    story.append(Paragraph("An Empirical Health Economics & Operational Systems Study Across 137 Acute Hospital Trusts and 16 Canonical Tumour Categories", style_subtitle))
    story.append(Paragraph("<b>Health Economics & Clinical Systems Consortium</b> &nbsp;|&nbsp; <i>Official Telemetry Release 2026</i> &nbsp;|&nbsp; Grounded in Zaanix Sandboxed DuckDB Workspace <code>76399c8f-81db-4db2-b277-652dcea8527e</code>", style_meta))

    # Abstract Box
    abstract_text = (
        "<b>Background:</b> In October 2023, NHS England restructured cancer waiting times by consolidating 10 legacy operational targets into three core standards: the 28-day Faster Diagnosis Standard (FDS, 80% target), the 31-day Decision-to-Treat standard (96% target), and the 62-day Referral-to-Treatment standard (85% target). This study evaluates whether this reform resolved operational congestion or catalyzed an unmonitored decoupling between front-end diagnostic triage and definitive therapy.<br/>"
        "<b>Methods:</b> We evaluated 247,636 provider-pathway records across 137 active acute NHS trusts (April 2021–August 2026). Methods include segmented Interrupted Time-Series (ITS) regressions with HAC standard errors (n=53 months), paired hypothesis tests on quarterly outcome cohorts (n=135 trusts), cross-tumour elasticity models, and spatial Gini inequality decomposition.<br/>"
        "<b>Results:</b> (1) <i>The 'Rule-Out Illusion' & Malignancy Triage Deficit (MTD):</i> While national FDS reached 78.56% in August 2026, outcome-stratified analysis revealed that patients with confirmed malignant neoplasm face an average compliance rate of only 54.83% compared to 79.53% for benign exclusions—a statistically overwhelming <b>25.06 percentage point Malignancy Triage Deficit</b> (t=18.38, p=1.88e-38; Wilcoxon W=47.0, p=1.91e-23). (2) <i>Interrupted Time Series:</i> The October 2023 reform reversed pre-reform secular decline (post-reform slope shift beta_3 = +0.2845%/mo, p&lt;0.001); however, the realized net recovery velocity (+0.1704%/mo) implies that achieving the 85% target will require 6.4 years (projected late 2032/early 2033), missing the statutory March 2029 target. (3) <i>Pathway Bifurcation:</i> Decoupling is strongly bimodal. Skin (-1.61 pp gap; 85.59% 62d compliance) operates with high velocity, whereas Head &amp; Neck (+19.18 pp gap; 56.68% 62d compliance), Lung (+18.85 pp gap; 61.09% 62d compliance), and Colorectal (16.9% waiting &gt;104 days) face catastrophic queueing. (4) <i>Spatial Inequality:</i> Spatial Gini inequality for the Decoupling Gap (G=0.1781) is over 4.4 times higher than FDS triage (G=0.0404), with the Midlands facing a +11.83 pp gap.<br/>"
        "<b>Conclusion:</b> Accelerating diagnostic triage without proportional expansions in surgical theater capacity and clinical oncology creates a dangerous 'pipeline illusion.' Policy must mandate malignancy-stratified FDS reporting and ring-fenced cancer surgical hubs."
    )
    abstract_table = Table([[Paragraph(abstract_text, style_abstract_body)]], colWidths=[178 * mm])
    abstract_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#F1F5F9")),
        ("BOX", (0, 0), (-1, -1), 0.8, colors.HexColor("#CBD5E1")),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
    ]))
    story.append(abstract_table)
    story.append(Spacer(1, 8))

    # Section 1: Introduction
    story.append(Paragraph("1. Introduction and Policy Context", style_h1))
    story.append(Paragraph(
        "Cancer remains the leading cause of avoidable mortality in England, accounting for over 135,000 deaths annually. Clinical survival is acutely sensitive to elapsed duration along the referral-to-treatment continuum: multi-centre oncology studies establish that each four-week delay in cancer surgery or definitive radiotherapy incurs a 6% to 13% escalation in all-cause mortality (Hanna et al., 2020; Sud et al., 2020). For two decades, English cancer delivery was monitored through a framework of ten standards established under the NHS Cancer Plan (2000). By 2022, however, this architecture faced severe clinical criticism for incentivizing administrative appointment-booking within 14 days rather than delivering definitive diagnostic clarity (Quinn et al., 2024; Johnson, 2024).",
        style_body
    ))
    story.append(Paragraph(
        "In October 2023, NHS England enacted a fundamental policy reform, replacing the legacy 10-standard framework with three unified operational targets: the <b>28-Day Faster Diagnosis Standard (FDS; target 80%)</b>, the <b>31-Day Decision-to-Treat Standard (target 96%)</b>, and the <b>62-Day Referral-to-Treatment Standard (target 85%)</b>. While welcomed by hospital administrators for reducing data burdens, the operational systemic effects of this reform have not been systematically evaluated. Specifically, does prioritizing front-end 28-day triage resolve cancer care delays, or does it decouple diagnostic exclusion from downstream curative treatment?",
        style_body
    ))

    # Figure 1: Time Series & Outcome Disparity
    story.append(Spacer(1, 4))
    story.append(make_fig1_ts_and_outcomes())
    story.append(Spacer(1, 4))
    story.append(Paragraph(
        "<b>Figure 1:</b> (a) Monthly national cancer waiting times compliance across the English NHS (April 2021–August 2026), highlighting the October 2023 policy inflection; (b) The 'Rule-Out Illusion': FDS compliance disaggregated by clinical outcome pathway across recent financial quarters.",
        style_meta
    ))
    story.append(Spacer(1, 6))

    # Section 2: Econometric Model & The Malignancy Triage Deficit
    story.append(Paragraph("2. Econometric Methodology and Interrupted Time Series Results", style_h1))
    story.append(Paragraph(
        "To test whether the October 2023 reform altered the underlying operational trajectory of cancer care, we estimated a segmented Interrupted Time-Series (ITS) regression on monthly 62-day definitive treatment compliance across 53 consecutive cycles (April 2022–August 2026) under unified definitions: <i>Y<sub>t</sub> = &beta;<sub>0</sub> + &beta;<sub>1</sub> T<sub>t</sub> + &beta;<sub>2</sub> D<sub>t</sub> + &beta;<sub>3</sub> P<sub>t</sub> + &epsilon;<sub>t</sub></i>, where <i>T<sub>t</sub></i> is time elapsed, <i>D<sub>t</sub></i> is the post-reform step indicator, and <i>P<sub>t</sub></i> is post-reform elapsed months. Heteroscedasticity and autocorrelation were modeled using Newey-West HAC covariance estimators with three lags.",
        style_body
    ))

    # Table 1: ITS Regression Results
    t1_data = [
        [Paragraph("<b>Model Parameter</b>", style_table_header),
         Paragraph("<b>Coefficient (&beta;)</b>", style_table_header),
         Paragraph("<b>HAC Std. Err.</b>", style_table_header),
         Paragraph("<b>z-statistic</b>", style_table_header),
         Paragraph("<b>p-value</b>", style_table_header),
         Paragraph("<b>95% Conf. Interval</b>", style_table_header)],
        [Paragraph("Baseline Intercept (&beta;<sub>0</sub>)", style_table_cell), Paragraph("65.6530%", style_table_cell), Paragraph("0.689", style_table_cell), Paragraph("95.23", style_table_cell), Paragraph("&lt; 0.001", style_table_cell), Paragraph("[64.302, 67.004]", style_table_cell)],
        [Paragraph("Pre-Reform Secular Trend (&beta;<sub>1</sub>)", style_table_cell), Paragraph("-0.1141% / mo", style_table_cell), Paragraph("0.066", style_table_cell), Paragraph("-1.72", style_table_cell), Paragraph("0.086", style_table_cell), Paragraph("[-0.244, +0.016]", style_table_cell)],
        [Paragraph("Reform Discrete Step Shift (&beta;<sub>2</sub>)", style_table_cell), Paragraph("+2.0690 pp", style_table_cell), Paragraph("0.998", style_table_cell), Paragraph("2.07", style_table_cell), Paragraph("0.038", style_table_cell), Paragraph("[+0.113, +4.025]", style_table_cell)],
        [Paragraph("Post-Reform Trajectory Slope (&beta;<sub>3</sub>)", style_table_cell), Paragraph("+0.2845% / mo", style_table_cell), Paragraph("0.068", style_table_cell), Paragraph("4.18", style_table_cell), Paragraph("&lt; 0.001", style_table_cell), Paragraph("[+0.151, +0.418]", style_table_cell)],
        [Paragraph("<b>Net Post-Reform Velocity (&beta;<sub>1</sub>+&beta;<sub>3</sub>)</b>", style_table_cell), Paragraph("<b>+0.1704% / mo</b>", style_table_cell), Paragraph("<b>0.041</b>", style_table_cell), Paragraph("<b>4.15</b>", style_table_cell), Paragraph("<b>&lt; 0.001</b>", style_table_cell), Paragraph("<b>[+0.090, +0.251]</b>", style_table_cell)],
    ]
    t1_tab = Table(t1_data, colWidths=[42 * mm, 28 * mm, 22 * mm, 20 * mm, 20 * mm, 46 * mm])
    t1_tab.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1E293B")),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#CBD5E1")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F8FAFC")]),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]))
    story.append(t1_tab)
    story.append(Spacer(1, 5))
    story.append(Paragraph(
        "<b>Table 1:</b> Segmented Interrupted Time-Series (ITS) estimation of national 62-day treatment compliance (R<sup>2</sup> = 0.642, F(3, 49) = 76.22, p &lt; 10<sup>-17</sup>, Durbin-Watson = 1.791).",
        style_meta
    ))
    story.append(Spacer(1, 6))

    story.append(Paragraph(
        "While the reform successfully arrested the pre-reform decay (-0.114%/mo) and induced a positive trajectory shift (&beta;<sub>3</sub> = +0.285%/mo, p &lt; 0.001), the net recovery pace (+0.1704%/mo or +2.04 pp/year) is profoundly insufficient. To bridge the 13.10 pp deficit separating August 2026 performance (71.90%) from the statutory 85.0% threshold requires 76.9 months (&approx; 6.4 years), delaying attainment to <b>late 2032 or 2033</b> and substantially breaching the government's official March 2029 commitment.",
        style_body
    ))

    # Section 3: The Malignancy Triage Deficit
    story.append(Paragraph("3. The 'Rule-Out Illusion' and the Malignancy Triage Deficit (MTD)", style_h1))
    story.append(Paragraph(
        "A critical vulnerability of the 28-day Faster Diagnosis Standard is its structural insensitivity to diagnostic outcomes. In official reporting, all referred patients are pooled into a single denominator. Disaggregating the newly released quarterly collections (Table 2) demonstrates that headline FDS performance (~78%) is an artifact of composition: over 93.8% of referrals have cancer ruled out rapidly (79.53% compliance), whereas patients with confirmed malignancy experience a dismal <b>54.83% compliance rate</b>.",
        style_body
    ))

    # Table 2: Paired Deficit Results
    t2_data = [
        [Paragraph("<b>Reporting Period</b>", style_table_header),
         Paragraph("<b>Outcome Sub-Cohort</b>", style_table_header),
         Paragraph("<b>Total Evaluated</b>", style_table_header),
         Paragraph("<b>Within 28 Days</b>", style_table_header),
         Paragraph("<b>Compliance %</b>", style_table_header),
         Paragraph("<b>Malignancy Deficit (pp)</b>", style_table_header)],
        [Paragraph("2025/26 Q3", style_table_cell), Paragraph("Ruling out of cancer", style_table_cell), Paragraph("1,570,920", style_table_cell), Paragraph("1,227,250", style_table_cell), Paragraph("78.12%", style_table_cell), Paragraph("—", style_table_cell)],
        [Paragraph("2025/26 Q3", style_table_cell), Paragraph("<b>Diagnosis of cancer (Malignant)</b>", style_table_cell), Paragraph("110,775", style_table_cell), Paragraph("61,705", style_table_cell), Paragraph("<b>55.70%</b>", style_table_cell), Paragraph("<b>-22.42 pp</b>", style_table_cell)],
        [Paragraph("2025/26 Q4", style_table_cell), Paragraph("Ruling out of cancer", style_table_cell), Paragraph("1,538,275", style_table_cell), Paragraph("1,219,540", style_table_cell), Paragraph("79.28%", style_table_cell), Paragraph("—", style_table_cell)],
        [Paragraph("2025/26 Q4", style_table_cell), Paragraph("<b>Diagnosis of cancer (Malignant)</b>", style_table_cell), Paragraph("108,500", style_table_cell), Paragraph("59,445", style_table_cell), Paragraph("<b>54.79%</b>", style_table_cell), Paragraph("<b>-24.49 pp</b>", style_table_cell)],
        [Paragraph("2026/27 Q1", style_table_cell), Paragraph("Ruling out of cancer", style_table_cell), Paragraph("1,543,520", style_table_cell), Paragraph("1,227,565", style_table_cell), Paragraph("79.53%", style_table_cell), Paragraph("—", style_table_cell)],
        [Paragraph("2026/27 Q1", style_table_cell), Paragraph("<b>Diagnosis of cancer (Malignant)</b>", style_table_cell), Paragraph("101,515", style_table_cell), Paragraph("55,660", style_table_cell), Paragraph("<b>54.83%</b>", style_table_cell), Paragraph("<b>-24.70 pp</b>", style_table_cell)],
    ]
    t2_tab = Table(t2_data, colWidths=[24 * mm, 46 * mm, 28 * mm, 28 * mm, 24 * mm, 28 * mm])
    t2_tab.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#0F172A")),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#CBD5E1")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F8FAFC")]),
        ("TOPPADDING", (0, 0), (-1, -1), 2.8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 2.8),
    ]))
    story.append(t2_tab)
    story.append(Spacer(1, 4))
    story.append(Paragraph(
        "<b>Table 2:</b> Outcome-stratified FDS cohorts across English NHS acute providers. Paired t-test across 135 acute trusts confirms a mean Malignancy Triage Deficit of <b>+25.06 percentage points</b> (t = 18.383, p = 1.88 &times; 10<sup>-38</sup>; Wilcoxon W = 47.0, p = 1.91 &times; 10<sup>-23</sup>).",
        style_meta
    ))
    story.append(Spacer(1, 6))

    # Section 4: Tumour Pathway Asymmetry and Regional Inequity
    story.append(Paragraph("4. Tumour Pathway Heterogeneity and Regional Healthcare Equity", style_h1))
    story.append(Paragraph(
        "Operational decoupling varies dramatically across clinical specialties (Figure 2a). Pathways relying on visual inspection and local excision (Skin: FDS = 83.98%, 62d = 85.59%, Decoupling Gap = -1.61 pp) maintain high equilibrium throughput. Conversely, multi-modality visceral pathways suffer acute queueing bottlenecks: <b>Head &amp; Neck</b> exhibits the highest decoupling gap in the NHS (+19.18 pp; 56.68% 62d compliance), followed closely by <b>Lung</b> (+18.85 pp gap; 61.09% 62d compliance), <b>Breast</b> (+17.11 pp gap; 70.92% 62d compliance), and <b>Lower Gastrointestinal/Colorectal</b> (+5.73 pp gap; 58.79% 62d compliance, with 16.9% waiting &gt;104 days).",
        style_body
    ))

    # Figure 2: Tumour and Regional
    story.append(Spacer(1, 4))
    story.append(make_fig2_tumour_and_regional())
    story.append(Spacer(1, 4))
    story.append(Paragraph(
        "<b>Figure 2:</b> (a) Tumour Pathway Decoupling Gap across 8 major malignancies; (b) Regional Decoupling Gap across NHS England regions, highlighting geographical disparity.",
        style_meta
    ))
    story.append(Spacer(1, 6))

    story.append(Paragraph(
        "Regional analysis reveals profound geographic inequity (Figure 2b). Spatial Gini inequality for the Decoupling Gap (G = 0.1781) is over 4.4 times higher than for front-end FDS triage (G = 0.0404). While patients across all regions receive 28-day triage at comparable rates (73.5% to 78.4%), access to definitive cancer treatment within 62 days varies from 72.03% in the North West down to 64.43% in the Midlands (an 11.83 pp decoupling penalty) and 65.62% in the East of England (with 18.5% extreme &gt;104-day backlog).",
        style_body
    ))

    # Section 5: Trust Decoupling Quadrant Matrix
    story.append(Paragraph("5. Hospital Trust Decoupling Matrix and Econometric Determinants", style_h1))
    story.append(Paragraph(
        "Mapping 137 acute hospital trusts onto a coordinate space defined by national median FDS (77.57%) and 62-day compliance (71.36%) identifies four distinct operational archetypes (Figure 3). While specialist cancer centers like Clatterbridge (FDS=88.1%, 62d=85.2%) occupy the resilient quadrant, major tertiary teaching hospitals—including Guy's &amp; St Thomas' (FDS=79.3%, 62d=53.3%, gap=+26.04 pp), Sheffield Teaching (gap=+21.81 pp), and Leicester (gap=+18.56 pp)—are trapped in the 'Bottleneck Decoupled' quadrant.",
        style_body
    ))

    # Figure 3: Scatter Plot
    story.append(Spacer(1, 4))
    story.append(make_fig3_trust_quadrant_scatter())
    story.append(Spacer(1, 4))
    story.append(Paragraph(
        "<b>Figure 3:</b> Operational Decoupling Matrix of 137 English acute hospital trusts. Dashed lines denote national medians.",
        style_meta
    ))
    story.append(Spacer(1, 6))

    # Cross-Trust OLS Regression Table
    t3_data = [
        [Paragraph("<b>Predictor Variable</b>", style_table_header),
         Paragraph("<b>Coefficient (&gamma;)</b>", style_table_header),
         Paragraph("<b>Robust Std. Err. (HC1)</b>", style_table_header),
         Paragraph("<b>t-statistic</b>", style_table_header),
         Paragraph("<b>p-value</b>", style_table_header),
         Paragraph("<b>95% Conf. Interval</b>", style_table_header)],
        [Paragraph("Intercept (&alpha;)", style_table_cell), Paragraph("53.5380", style_table_cell), Paragraph("15.106", style_table_cell), Paragraph("3.54", style_table_cell), Paragraph("&lt; 0.001", style_table_cell), Paragraph("[23.931, 83.145]", style_table_cell)],
        [Paragraph("ln(Suspected Referral Volume)", style_table_cell), Paragraph("+0.9019", style_table_cell), Paragraph("0.737", style_table_cell), Paragraph("1.22", style_table_cell), Paragraph("0.221", style_table_cell), Paragraph("[-0.543, +2.347]", style_table_cell)],
        [Paragraph("31-Day Treatment Compliance (%)", style_table_cell), Paragraph("-0.6622", style_table_cell), Paragraph("0.106", style_table_cell), Paragraph("-6.25", style_table_cell), Paragraph("&lt; 0.001", style_table_cell), Paragraph("[-0.870, -0.455]", style_table_cell)],
        [Paragraph("Malignancy Triage Deficit (MTD, pp)", style_table_cell), Paragraph("+0.2072", style_table_cell), Paragraph("0.075", style_table_cell), Paragraph("2.77", style_table_cell), Paragraph("0.006", style_table_cell), Paragraph("[+0.061, +0.354]", style_table_cell)],
    ]
    t3_tab = Table(t3_data, colWidths=[46 * mm, 26 * mm, 26 * mm, 18 * mm, 18 * mm, 44 * mm])
    t3_tab.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1E293B")),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#CBD5E1")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F8FAFC")]),
        ("TOPPADDING", (0, 0), (-1, -1), 2.8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 2.8),
    ]))
    story.append(t3_tab)
    story.append(Spacer(1, 4))
    story.append(Paragraph(
        "<b>Table 3:</b> Cross-trust determinants of the Decoupling Gap (&Delta;<sub>i</sub> = FDS<sub>i</sub> - 62d<sub>i</sub>) across 134 acute hospital trusts (R<sup>2</sup> = 0.382, F(3, 130) = 33.03, p &lt; 10<sup>-15</sup>).",
        style_meta
    ))
    story.append(Spacer(1, 6))

    # Section 6: Policy Recommendations & Conclusion
    story.append(Paragraph("6. Policy Implications and Strategic Blueprint", style_h1))
    story.append(Paragraph(
        "Our econometric and queueing findings carry direct strategic implications for the UK Department of Health and Social Care (DHSC) and NHS England:<br/>"
        "1. <b>Bifurcate the Faster Diagnosis Standard</b>: Replace the aggregate FDS target with two distinct mandatory metrics: <i>FDS<sub>Rule-Out</sub></i> (target 85%) and <i>FDS<sub>Diagnosed</sub></i> (target 70%). This eliminates the mathematical mask that allows high-volume benign exclusions to conceal delays for confirmed cancer patients.<br/>"
        "2. <b>Ring-Fenced Protected Elective Cancer Surgical Hubs</b>: Because 31-day treatment execution is the single most powerful compressional force against decoupling (&gamma; = -0.662, p &lt; 0.001), trusts must structurally isolate elective oncological operating suites from acute emergency surgical admissions.<br/>"
        "3. <b>Targeted Capital Allocation via the Decoupling Gap Index</b>: NHS England capital recovery funding should be deployed directly to high-decoupling trusts in the Midlands and East of England to fund robotic colorectal theaters, EBUS suites, and digital histopathology networks.",
        style_body
    ))
    story.append(Paragraph(
        "<b>Conclusion:</b> Accelerating diagnostic triage without expanding downstream surgical and oncological capacity produces a dangerous 'pipeline illusion.' England cannot solve its cancer waiting times crisis by clearing negative biopsies faster. The transition from diagnostic speed to curative delivery requires synchronized end-to-end capacity planning from primary care referral to the operating theater.",
        style_body
    ))
    story.append(Spacer(1, 6))

    # References
    story.append(Paragraph("References", style_h1))
    refs = [
        "1. Butnari, V., et al. (2025). Understanding the costs of late-stage cancer diagnosis from a large DGH in England. <i>BMC Health Serv Res</i>, 25, 657.",
        "2. Carson, L. N., et al. (2026). Real-world effectiveness of AI lesion triage on cancer waiting times. <i>Br J Dermatol</i>, 194(6), ljag086.016.",
        "3. Hanna, T. P., et al. (2020). Mortality due to cancer treatment delay: systematic review and meta-analysis. <i>BMJ</i>, 371, m4087.",
        "4. Hayes, H., Meacock, R., et al. (2024). How do family doctors respond to reduced waiting times for cancer diagnosis? <i>Eur J Health Econ</i>, 25, 567–582.",
        "5. Johnson, P. (2024). Updating the NHS cancer waiting time standards. <i>BMJ Oncology</i>, 3(1), e000337.",
        "6. Lam, C. H. M., Mason, T., & Hollingsworth, B. (2026). Measuring performance in cancer services during COVID-19 and beyond: a novel case throughput metric. <i>J Public Health</i>, 48(1), fdag041.",
        "7. Lam, C. H. M., et al. (2026). Enduring inequalities in cancer care experience across England: longitudinal analysis. <i>J Public Health</i>, 48(1), fdag065.",
        "8. Maringe, C., et al. (2020). The impact of COVID-19 on cancer deaths due to delays in England: modelling study. <i>Lancet Oncol</i>, 21(8), 1023–1034.",
        "9. Nour, S., et al. (2026). From screen to scalpel: safety and efficiency of direct-to-surgery teledermatology. <i>BMJ Open Qual</i>, 15(1), e004129.",
        "10. Quinn, L., Bird, P., & Lilford, R. (2024). Effect of cancer waiting time standards in the English NHS: a threshold analysis. <i>BMC Health Serv Res</i>, 24, 11350.",
        "11. Sud, A., Torr, B., et al. (2020). Effect of delays in the 2-week-wait cancer referral pathway on cancer survival in the UK. <i>Lancet Oncol</i>, 21(8), 1035–1044.",
        "12. Tredget, G., et al. (2026). Lung cancer pathway inequalities for adults with severe mental health conditions. <i>medRxiv / BMJ Oncology</i>, doi:10.64898/2026.06.08.26355143."
    ]
    for r in refs:
        story.append(Paragraph(r, ParagraphStyle("RefText", parent=styles["Normal"], fontName="Helvetica", fontSize=6.5, leading=8.8, textColor=colors.HexColor("#334155"), spaceAfter=2.5)))

    # Build PDF using NumberedCanvas
    doc.build(story, canvasmaker=NumberedCanvas)
    print(f"Successfully generated publication-ready PDF: {OUTPUT_PDF} ({os.path.getsize(OUTPUT_PDF)} bytes)")


if __name__ == "__main__":
    build_pdf()
