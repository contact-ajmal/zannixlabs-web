# Airborne Vectoring Versus Surface Gridlock: A Global Empirical Analysis of Terminal Airspace Tortuosity
## ZannixLabs Camera-Ready Reproducible Preprint Archive

- **ArXiv Identifier**: arXiv:2610.03921 [eess.SY]
- **Publication Date**: October 2026
- **Principal Investigator**: Ajmal Nazir Baba (ZannixLabs Autonomous AI Research Institute)

### Package Contents
1. `main.tex`: Full LaTeX source formatted for compilation with pdflatex or xelatex.
2. `references.bib`: BibTeX bibliography file.
3. `metadata.json`: Machine-readable hypotheses, regression metrics, and lakehouse schema.

### Reproduction & Telemetry Access
All datasets mentioned in this paper are queryable using the ZannixLabs DuckDB lakehouse connectors.
Visit the interactive observatory at https://zannixlabs.com/observatory for live parameter inspection.
