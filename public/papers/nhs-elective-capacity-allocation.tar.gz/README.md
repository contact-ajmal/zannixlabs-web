# Where Should Additional NHS Elective Capacity Go?
## An Evidence-Based Framework for Reducing Long Waits Under Operational Constraints

### ZannixLabs Independent Research Initiative
**Lead Authors**: Ajmal Baba (Founder & Lab Director, AI Agent Assistant) & Zannix Data Agent (Lead Autonomous Research Engine)  
**Research Entity**: Zannix Research Collective & ZannixLabs Applied AI Research  
**Correspondence**: `ajmalbaba@zannixlabs.com` | London, UK | [www.zannixlabs.com](https://www.zannixlabs.com)  
**Zaanix Platform Project Identifier**: `nhs_elective_recovery`  
**Active Lakehouse Workspace**: `76399c8f-81db-4db2-b277-652dcea8527e`  
**Dedicated Lakehouse Schema**: `nhs_elective_recovery`  
**License**: Creative Commons Attribution 4.0 International (CC-BY-4.0)

---

## 1. Executive Mission & Primary Research Question

### Working Title
*“Where Should Additional NHS Elective Capacity Go? An Evidence-Based Framework for Reducing Long Waits Under Operational Constraints.”*

### Primary Research Question
Given limited additional elective-care capacity (theatre hours, outpatient sessions, surgical hub slots), which provider–specialty combinations should receive it, and under what operational assumptions would this reduce long waits most effectively?

### Core Supporting Questions
1. **Inflow–Outflow Disequilibrium**: Which queues are expanding systematically because new clock starts exceed total recorded completions?
2. **The Residual Flow Trap**: How much apparent waiting list reduction represents clinical completions (admitted vs non-admitted) versus administrative list validation, patient transfers, or unrecorded clock stops?
3. **Queue-Tail Persistence**: Which specialties exhibit severe, persistent accumulation of ultra-long waits (>52 and >65 weeks)?
4. **Policy Trade-offs & Unintended Consequences**: When does targeting exclusively the longest waits displace time-sensitive routine pathways or create downstream bed bottlenecks?
5. **Robust Optimization**: Which capacity allocation rules perform best under volatile future demand shocks and delivery shortfalls?

---

## 2. Platform Architecture & Execution Mandate

This research executes natively on the **Zaanix Lakehouse & Autonomous Agent Platform** via MCP server tools:
- **Engine**: Vectorized DuckDB Lakehouse Engine (`http://localhost:4200/mcp`)
- **Ingestion Pipeline**: Automated and manual sync pipelines (`create_data_sync`, `run_data_sync`)
- **Governance**: Data profiling (`profile_dataset`), assertion suites (`create_quality_suite`), and PII guards (`scan_pii`)
- **Traceability**: Project metadata, protocols, and claims ledger persisted directly in DuckDB tables under `nhs_elective_recovery.*`
- **Interactive Delivery**: Native SQL Notebooks (`create_notebook`), Mosaic Dashboards (`create_mosaic_dashboard`), and Streamlit simulators (`create_app`)

---

## 3. Project Directory & Logical Structure

```
nhs_elective_capacity_framework/
├── README.md                           # This executive project brief
├── RESEARCH_PROTOCOL.md                 # Pre-specified statistical protocol
├── PROGRESS.md                          # Persistent cross-session progress tracker
├── DECISIONS.md                         # Architecture and methodology decision log
├── ASSUMPTIONS.md                       # Explicit modeling & clinical assumptions
├── LIMITATIONS.md                       # Comprehensive audit of public data limits
├── SOURCE_REGISTER.csv                  # Immutable register of raw datasets & SHA256 checksums
├── CLAIMS_LEDGER.csv                    # Traceability ledger tying claims to SQL queries
├── data/
│   ├── raw/                             # Original official NHS England publications
│   └── processed/                       # Curated Parquet marts & reconciliation tables
├── src/
│   ├── ingestion/                       # Zaanix sync pipeline and data loaders
│   ├── models/                          # Forecasting and age-structured queue simulator
│   └── optimization/                    # Capacity allocation algorithms & policies
├── notebooks/                           # Executable Jupyter and Zaanix SQL notebooks
├── tests/                               # Rigorous pytest unit tests for accounting & ageing
├── outputs/
│   ├── figures/                         # High-DPI publication figures
│   └── tables/                          # Summary and econometric regression tables
├── reports/                             # Technical manuscript, decision brief, pilot proposal
└── app/                                 # Interactive scenario simulator application
```

---

## 4. Analytical Scope & Focal Archetypes

- **National Foundation**: Complete NHS England acute trust coverage (1.085M+ rows across 461 reporting organisations).
- **Regional Deep-Dive**: **Birmingham and Solihull Integrated Care Board (ICB)**:
  - `RRK`: University Hospitals Birmingham NHS Foundation Trust (Major tertiary acute centre; 96,303 waiting pathways)
  - `RRJ`: The Royal Orthopaedic Hospital NHS Foundation Trust (Specialist elective orthopaedic centre; 13,473 waiting pathways)
  - `RQ3`: Birmingham Women's and Children's NHS Foundation Trust (Specialist tertiary paediatric/maternity)
- **Three Audited Specialties**:
  1. **Trauma & Orthopaedics (T&O)**: 851,183 national waiting pathways; 276,003 pathways with Decision to Admit (inpatient surgical bottleneck archetype).
  2. **Ophthalmology**: 625,063 national waiting pathways; high-throughput outpatient/cataract day-case archetype.
  3. **Ear, Nose & Throat (ENT)**: 590,233 national waiting pathways; severe 42.7% breach rate (>18w); mixed paediatric-adult archetype.
