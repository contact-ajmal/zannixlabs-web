#!/usr/bin/env python3
"""
Unit tests for NHS Elective Waiting-List Recovery Framework:
1. Stock-Flow Accounting Identity Reconciliation
2. Discrete Cohort Aging and Bound Integrity
3. Non-Negative Residual Removal Preservation
4. Capacity Allocation Budget Conservation
"""

import pytest
import numpy as np
from src.models.age_structured_queue_simulator import AgeStructuredQueueSimulator

def test_stock_flow_accounting_identity():
    """Verify that Start_Stock + Starts - Admitted - NonAdmitted - Residual == End_Stock."""
    start_stock = 94792
    starts = 25674
    adm_comp = 3073
    non_adm_comp = 17150
    end_stock = 96303
    
    # Calculate derived net residual removal
    expected_end = start_stock + starts - adm_comp - non_adm_comp
    net_residual = expected_end - end_stock
    
    assert expected_end == 100243
    assert net_residual == 3940
    assert (start_stock + starts - adm_comp - non_adm_comp - net_residual) == end_stock

def test_simulator_aging_progression():
    """Verify that cohort aging shifts stock into older wait bands monotonically."""
    state = {
        "end_stock": 10000,
        "incomplete_within_18w": 7000,
        "incomplete_gt_18w": 3000,
        "clock_starts": 2000,
        "admitted_completions": 200,
        "non_admitted_completions": 1500,
        "total_completions": 1700,
        "net_residual_removals": 200,
        "provider_org_code": "TEST",
        "treatment_function_name": "Test Service"
    }
    sim = AgeStructuredQueueSimulator(state)
    initial_gt52 = sim.w_52_65 + sim.w_gt_65
    
    # Run 6 months forward with zero additional capacity
    for _ in range(6):
        res = sim.step(additional_capacity=0, shock_factor=1.0, delivery_fraction=1.0)
    
    # Under status quo, backlog cohorts should age and increase >52w burden
    assert res["stock"] > 0
    assert res["pathway_weeks_gt52"] >= 0

def test_capacity_budget_conservation():
    """Verify that capacity allocation policies strictly conserve the total monthly budget."""
    TOTAL_BUDGET = 500
    cohorts = [
        {"provider": "RRK", "end_stock": 4712, "gt_18w": 1074, "starts": 1264, "comps": 917},
        {"provider": "RRK", "end_stock": 9466, "gt_18w": 3277, "starts": 2673, "comps": 2160},
        {"provider": "RRK", "end_stock": 8450, "gt_18w": 2728, "starts": 1627, "comps": 1292},
        {"provider": "RRJ", "end_stock": 11098, "gt_18w": 3942, "starts": 2265, "comps": 1948},
    ]
    
    # Policy 1: Proportional
    allocations_p1 = [TOTAL_BUDGET * (c["end_stock"] / sum(x["end_stock"] for x in cohorts)) for c in cohorts]
    assert np.isclose(sum(allocations_p1), TOTAL_BUDGET, atol=1e-5)
    
    # Policy 2: Long-Wait Burden
    allocations_p2 = [TOTAL_BUDGET * (c["gt_18w"] / sum(x["gt_18w"] for x in cohorts)) for c in cohorts]
    assert np.isclose(sum(allocations_p2), TOTAL_BUDGET, atol=1e-5)

def test_non_negative_queue_states():
    """Verify that queue bands cannot drop below zero under large additional capacity."""
    state = {
        "end_stock": 500,
        "incomplete_within_18w": 400,
        "incomplete_gt_18w": 100,
        "clock_starts": 50,
        "admitted_completions": 20,
        "non_admitted_completions": 40,
        "total_completions": 60,
        "net_residual_removals": 10,
        "provider_org_code": "TEST",
        "treatment_function_name": "Test Service"
    }
    sim = AgeStructuredQueueSimulator(state)
    # Inject massive additional capacity exceeding entire queue
    res = sim.step(additional_capacity=2000, shock_factor=1.0, delivery_fraction=1.0)
    assert res["stock"] >= 0
    assert res["within_18w"] >= 0
    assert res["gt_18w"] >= 0
    assert res["gt_52w"] >= 0
    assert res["gt_65w"] >= 0
