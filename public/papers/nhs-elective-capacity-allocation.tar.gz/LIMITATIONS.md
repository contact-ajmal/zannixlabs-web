# Comprehensive Limitations & Data-Quality Audit
## NHS Elective Waiting-List Recovery Framework

### 1. Lack of Patient-Level Clinical Acuity in Public Aggregate RTT
- **Limitation**: Official public RTT datasets provide aggregated count distributions by weekly waiting-time band, provider, and treatment function. They do not record individual patient clinical priority (P2 urgent, P3 within 3 months, P4 routine), ASA physical status score, or comorbidity profiles.
- **Operational Precaution**: Our models do NOT optimize individual clinical triage decisions. The framework evaluates macro capacity distribution across service units, leaving clinical prioritisation entirely to attending surgical teams.

### 2. The Non-Admitted Completion Ambiguity
- **Limitation**: A "Completed Pathway for Non-Admitted Patient" represents a clock stop that did not involve an inpatient/daycase admission. This can represent:
  1. Definitive outpatient clinical treatment (e.g. medical therapy, injection).
  2. Clinical discharge following negative diagnostic evaluation.
  3. Patient decision not to proceed with treatment.
  4. Did Not Attend (DNA) leading to referral return to GP.
- **Precaution**: Non-admitted completions must NEVER be described uniformly as "patients receiving surgical treatment."

### 3. Reporting Breaks and Missing Trust Estimates
- **Limitation**: Acute trusts periodically undergo electronic patient record (EPR) migrations (e.g. Epic, Cerner implementations) resulting in multi-month reporting pauses (e.g., Manchester University NHS FT in 2023–2024). NHS England Overview files include estimated figures for non-reporting trusts, whereas monthly provider full extracts exclude them.
- **Precaution**: Comparisons between national overview totals and bottom-up sums from provider extracts must explicitly note the missing-trust estimation gap.

### 4. Unobserved Upstream Diagnostic & Workforce Bottlenecks
- **Limitation**: RTT data records waiting duration from referral to completion, but does not explicitly timestamp intermediate milestones (e.g. date MRI completed, date outpatient appointment held) for incomplete pathways.
- **Precaution**: Theatre and outpatient conversions are modeled as scenario assumptions grounded in GIRFT and National Cost Collection benchmarks rather than directly observed timestamps.
