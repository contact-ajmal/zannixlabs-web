# Architecture & Methodology Decision Log
## NHS Elective Waiting-List Recovery Framework

### Decision 1: Execution Native to Zaanix Platform via MCP
- **Date**: 2026-10-16
- **Context**: The user and research skill mandate execution directly on the Zaanix Platform lakehouse rather than detached local scripts.
- **Decision**: All raw datasets are ingested via `create_data_sync` into Zaanix DuckDB storage. All transformations and analytical marts are materialized in a dedicated schema `nhs_elective_recovery` using `execute_query`. Governance suites, profiling, notebooks, and applications use native Zaanix MCP tools.
- **Consequences**: Complete reproducibility, sandboxed database execution, and instant availability of tables in the Zaanix UI.

### Decision 2: Study Period Selection (March 2026 – August 2026)
- **Date**: 2026-10-16
- **Context**: Pooling pre-pandemic (2018–2019), pandemic (2020–2021), and post-pandemic recovery periods without testing for structural breaks induces bias due to radical shifts in non-face-to-face outpatient appointments, triage practices, and capacity norms.
- **Decision**: Use the recent 6-month continuous panel (March 2026 – August 2026) for granular provider-level stock-flow calibration and optimization modeling, while using the long-term national overview (2007–2026) for macro context.
- **Consequences**: Captures contemporary clinical productivity, current referral patterns, and post-strike operational stability.

### Decision 3: Specialty Triad Selection
- **Date**: 2026-10-16
- **Context**: Need 2–3 specialties representing diverse clinical, operational, and physical resource archetypes.
- **Decision**: Select **Trauma & Orthopaedics (T&O)**, **Ophthalmology**, and **Ear, Nose & Throat (ENT)**.
- **Rationale**:
  - T&O: Inpatient admitted archetype, theatre-heavy, arthroplasty beds, highest absolute backlog (851k).
  - Ophthalmology: High-throughput day-case/outpatient surgical archetype (625k), cataract hubs.
  - ENT: Severe breach archetype (42.7% >18w), mixed medical/surgical outpatient triage (590k).

### Decision 4: Regional Focal Scope (Birmingham and Solihull ICB)
- **Date**: 2026-10-16
- **Context**: Ground national framework in an operational health system with distinct acute providers.
- **Decision**: Birmingham and Solihull ICB, examining University Hospitals Birmingham NHS FT (`RRK`), The Royal Orthopaedic Hospital NHS FT (`RRJ`), and Birmingham Women's and Children's NHS FT (`RQ3`).
- **Rationale**: High concentration of elective backlogs, clear operational differentiation between large multi-site tertiary trust (`RRK`) and single-specialty orthopaedic hospital (`RRJ`), providing ideal conditions to model capacity transfers and mutual aid.

### Decision 5: Explicit Retention of Net Residual Removals
- **Date**: 2026-10-16
- **Context**: Inflow minus outflow does not equal change in stock due to unrecorded clock stops and administrative validation.
- **Decision**: Calculate and retain `net_residual_removals` explicitly as a distinct flow term. Never silently clip negative residuals or conflate administrative removals with clinical treatments.
- **Consequences**: Protects decision-makers from overestimating clinical throughput gains.
