# Research Protocol: NHS Elective Capacity Allocation Framework
## Pre-Specified Statistical and Simulation Protocol

**Protocol Identifier**: `ZANNIX-NHS-RTT-2026-01`  
**Project Identifier**: `nhs_elective_recovery`  
**Registration Date**: October 2026  
**Status**: Pre-Specified Prior to Model Evaluation  

---

## 1. Background & Rationale
Following the COVID-19 pandemic and subsequent operational pressures, the NHS in England faces an unprecedented elective waiting list (>7.18 million unfinished Referral to Treatment pathways as of August 2026). While headline national targets focus on eliminating 65-week and 52-week waits, operational leaders (ICB directors of performance, Trust Chief Operating Officers, clinical directors) operate under hard physical constraints: finite operating theatre sessions, surgical beds, anaesthetic staffing, and outpatient clinic rooms.

Decisions regarding where to allocate additional elective capacity (e.g., Elective Recovery Fund allocations, surgical hub sessions, high-volume week initiatives, waiting list initiatives) often rely on crude historical shares or political pressure, rather than formal queueing theory, stochastic optimization, and robust counterfactual evaluation.

---

## 2. Research Questions
### Primary Question
Given limited additional elective-care capacity $\Delta C$, which provider–specialty combinations should receive it, and under what operational assumptions does this allocation minimize cumulative long-wait burden most effectively over 6- to 18-month planning horizons?

### Secondary Questions
1. How does the choice of allocation policy (proportional vs. long-wait targeting vs. robust stochastic optimization) alter queue tail percentiles ($P_{90}, P_{95}$) and 18-week compliance?
2. To what extent does aggressive targeting of the longest waits (>52w) cause displacement of mid-wait pathways (30–50w), accelerating future breach rates?
3. What proportion of apparent queue reduction is driven by genuine clinical throughput (admitted vs. non-admitted) versus administrative list validation and net residual removals?

---

## 3. Pre-Specified Endpoints & Metrics

### Primary Endpoint
- **Cumulative Long-Wait Pathway-Weeks ($\Omega_{T}$)**:
  $$\Omega_{T} = \sum_{t=1}^{T} \sum_{i \in \text{Providers}} \sum_{j \in \text{Specialties}} \sum_{w = 52}^{W_{\max}} (w - 52) \cdot N_{ij}(w, t)$$
  *Rationale*: Measures the integrated duration of human suffering and clinical risk beyond the 52-week constitutional ceiling, preventing "threshold gaming" where patients just below a cut-off (e.g. 51 weeks) are neglected to clear 53-week cases.

### Secondary Endpoints
1. **Absolute Long-Wait Headcount**: Number of unfinished pathways $>18$, $>52$, $>65$, and $>78$ weeks at horizon end $T$.
2. **Total Unfinished Pathways**: Aggregate stock size $S(T) = \sum_{w} N(w, T)$.
3. **Queue Tail Quantiles**: 90th and 95th percentiles of waiting time ($P_{90}, P_{95}$).
4. **Clinical Completion Yield**: Ratio of additional completed pathways to allocated session capacity.
5. **Inequality / Gini Coefficient**: Distribution of wait times across provider–specialty pairs.

---

## 4. Study Population & Scope

### National Analytical Foundation
- All acute NHS provider trusts in England reporting monthly Consultant-Led RTT statistics to NHS England (461 reporting codes, ~140 acute hospital trusts).

### Focal Regional Case Study: Birmingham and Solihull ICB
- `RRK`: University Hospitals Birmingham NHS Foundation Trust (tertiary multi-site acute trust).
- `RRJ`: The Royal Orthopaedic Hospital NHS Foundation Trust (specialist elective orthopaedic hospital).
- `RQ3`: Birmingham Women's and Children's NHS Foundation Trust (specialist paediatric/maternity).

### Focal Clinical Specialties
1. **Trauma and Orthopaedics (T&O - Code 110)**: High volume (851k stock), severe inpatient admission requirement (276k DTA), substantial arthroplasty bed requirement.
2. **Ophthalmology (Code 130)**: High volume (625k stock), rapid day-case surgical throughput (cataracts), outpatient diagnostic intensity.
3. **Ear, Nose and Throat (ENT - Code 120)**: High 18w breach rate (42.7%), long outpatient triage queues, mixed surgical/medical case-mix.

---

## 5. Candidate Forecasting & Arrival Models

Arrivals (new clock starts $\lambda_{ijt}$) and baseline completion rates ($\mu_{ijt}$) will be forecast using rolling-origin backtesting (train on months 1–4, validate on month 5, test on month 6):
1. **Seasonal Naïve**: $\hat{y}_{t} = y_{t-12}$
2. **Exponential Smoothing (Holt-Winters / ETS)**: Additive trend and seasonal decay.
3. **Hierarchical Ridge / Vector Autoregression (VAR)**: Modeling correlated demand shocks across surgical specialties.
4. **Outflow Decomposition**: Disaggregating completion capacity into Admitted ($\mu^{\text{adm}}$) and Non-Admitted ($\mu^{\text{non-adm}}$).

---

## 6. Age-Structured Queue Progression Model

The waiting list is formulated as a discrete-time age-structured matrix cohort model where weekly waiting age bands $w \in \{0, 1, \dots, 104+\}$ evolve every month ($\Delta t \approx 4.33$ weeks):

$$N_{ijt}(w) = \underbrace{N_{ij,t-1}(w - \Delta t)}_{\text{Surviving cohort from previous month}} - \underbrace{C_{ijt}^{\text{adm}}(w)}_{\text{Admitted removals}} - \underbrace{C_{ijt}^{\text{non}}(w)}_{\text{Non-admitted removals}} - \underbrace{R_{ijt}(w)}_{\text{Net residual removals}}$$

Where:
- $N_{ijt}(0) = \lambda_{ijt}$ (New clock starts).
- Incomplete pathways with Decision to Admit (DTA) are modeled as a dedicated sub-state $N^{\text{DTA}}(w)$ governed by theatre capacity constraints.
- Residual removals $R_{ijt}(w)$ are calibrated against observed historical stock-flow reconciliation residuals.

---

## 7. Capacity Allocation Policies Evaluated

Under a fixed budget of additional monthly capacity $\Delta C$ (e.g. $+5\%, +10\%, +15\%$ of baseline throughput):
1. **Policy 0 (Do Nothing / Status Quo)**: Baseline capacity $\mu_{0}$ unchanged.
2. **Policy 1 (Proportional Allocation)**: Capacity distributed proportional to total waiting list size:
   $$\Delta c_{ij} = \Delta C \cdot \frac{S_{ij}}{\sum S_{kl}}$$
3. **Policy 2 (Long-Wait Burden Allocation)**: Capacity distributed proportional to $>52$-week backlog density:
   $$\Delta c_{ij} = \Delta C \cdot \frac{N_{ij}(>52w)}{\sum N_{kl}(>52w)}$$
4. **Policy 3 (Net Inflow Deficit Allocation)**: Capacity allocated to queues where inflow exceeds outflow ($\lambda_{ij} - \mu_{ij} > 0$).
5. **Policy 4 (Greedy Marginal Reduction)**: Capacity sequentially allocated to the unit with highest instantaneous marginal reduction in $\Omega_{T}$.
6. **Policy 5 (Robust Stochastic Optimization)**: Solves a min-max regret formulation subject to uncertain demand shocks $\tilde{\lambda} \sim \mathcal{D}$ and delivery execution risk $\tilde{\alpha} \in [0.70, 1.00]$:
   $$\min_{\Delta c} \max_{\xi \in \Xi} \mathbb{E} \left[ \Omega_{T}(\Delta c, \xi) \right]$$

---

## 8. Sensitivity Analyses & Stability Criteria

1. **Demand Shocks**: $\pm 10\%$ and $\pm 20\%$ variance in referral rates.
2. **Delivery Shortfall**: Realised additional capacity constrained to $60\%$, $75\%$, and $90\%$ of planned allocation (staff sickness, theatre downtime).
3. **Residual Flow Cessation**: Testing queue dynamics if administrative validation removals drop to zero.
4. **Displacement Testing**: Measuring whether clearing $>52w$ waits increases the transition rate of $35-51w$ pathways into $>52w$ breaches.
5. **Recommendation Stability Rule**: A provider–specialty recommendation is deemed **robust** if and only if its policy ranking remains in the top tertile across $\ge 80\%$ of simulated perturbation scenarios.
