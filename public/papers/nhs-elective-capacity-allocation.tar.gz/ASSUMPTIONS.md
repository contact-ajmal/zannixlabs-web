# Explicit Modeling & Operational Assumptions
## NHS Elective Waiting-List Recovery Framework

### 1. Pathway vs. Unique Patient Identity
- **Assumption**: RTT data tracks *pathways*, not unique individuals. A patient with bilateral cataracts or multi-site joint degeneration may account for multiple concurrent pathways.
- **Operational Impact**: Reductions in waiting pathways do not equate 1:1 to unique individuals treated. Simulated benefits represent pathway clearances.

### 2. Time-Grid Discretization & Calendar Aging
- **Assumption**: Monthly published statistics aggregate pathways into weekly bins ($0-1w, 1-2w, \dots, 104+w$). In the discrete cohort model, 1 month corresponds to approximately 4.33 weeks of aging.
- **Handling**: Cohorts shift forward by 4 weeks in 28-day months and 5 weeks in 35-day statistical months, matching NHS England's financial calendar reporting cycle.

### 3. Resource Conversion Homogeneity
- **Assumption**: One completed pathway does NOT consume equivalent physical resources across specialties or admission settings.
- **Specification**:
  - T&O Admitted Pathway: Requires ~120–150 minutes of operating theatre time, 2.8 inpatient bed-days, and specialist orthopaedic surgical staff.
  - Ophthalmology Daycase Pathway: Requires ~25–35 minutes of theatre time, 0 overnight beds, and local anaesthetic.
  - ENT Pathway: Bimodal distribution (simple grommets/tonsils day-case vs complex head & neck inpatient cases).

### 4. Residual Flow Behavior Under Counterfactuals
- **Assumption**: Administrative validation and patient self-removals (residual flow) will continue at their historical empirical rates ($\approx 11.5\% - 16.1\%$ of clock starts) unless explicitly tested in a cessation stress-test.
- **Sensitivity Check**: A zero-residual scenario is evaluated to bound worst-case queue expansion.

### 5. Patient Willingness and Travel Feasibility for Mutual Aid
- **Assumption**: Cross-provider capacity pooling (e.g. diverting routine orthopaedic cases from `RRK` to `RRJ`) assumes that up to 35% of routine elective patients are clinically eligible and willing to travel within the ICB footprint.
