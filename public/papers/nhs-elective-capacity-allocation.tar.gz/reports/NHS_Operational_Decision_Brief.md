# Executive Decision Brief for NHS Operational Leaders
## Where Should Additional Elective Capacity Go?

**Target Audience**: Integrated Care Board (ICB) Chief Executive Officers, Trust Chief Operating Officers, Medical Directors, and System SROs for Elective Care  
**Regional Context**: Birmingham and Solihull ICB & English Acute Hospital Trusts  
**Authoring Entity**: ZannixLabs Applied AI & Healthcare Systems Research  
**Date**: October 2026  

---

## 1. The Core Operational Dilemma

NHS operational leaders face intense pressure to eliminate 65-week and 52-week waiting list breaches. However, elective recovery funding and theatre sessions are frequently allocated via:
1. Equal percentage increases across all specialties (proportional peanut-buttering).
2. Crisis-driven redeployment to whichever service breached headlines most recently.

Our research demonstrates that **both approaches waste substantial capacity** and risk accelerating waiting times in linked services.

---

## 2. Top Five Strategic Recommendations

### 1. Shift Orthopaedic Elective Inflow to Dedicated Specialist Centres
- **Finding**: In Birmingham and Solihull, University Hospitals Birmingham (`RRK`) carries 4,712 T&O pathways (1,074 breaching 18w), while The Royal Orthopaedic Hospital (`RRJ`) carries 11,098 T&O pathways (3,942 breaching 18w).
- **Recommendation**: Establish a formal ICB-wide mutual aid pooling agreement diverting routine hip and knee arthroplasty referrals directly into protected high-volume surgical lists at `RRJ`.
- **Expected Impact**: Reduces Birmingham T&O 52-week breaches by **64% within 12 months** by insulating surgical beds from acute emergency medical admissions at Queen Elizabeth and Heartlands hospitals.

### 2. Guard Against the "Residual Flow Illusion"
- **Finding**: Nationally, **14.25% of all new clock starts (237,477 pathways/month)** are removed from waiting lists via net residual removals (administrative list cleansing, validation, and unrecorded clock stops) rather than treated clinical completions.
- **Recommendation**: Operational planning MUST decouple administrative validation targets from physical theatre capacity. Do not treat falling waiting lists as proof of surgical productivity gains.

### 3. Adopt Robust Stochastic Allocation (Policy 5) Over Strict Long-Wait Chasing
- **Finding**: Allocating capacity exclusively to the oldest pathways (>52w) causes a secondary breach spike 6–9 months later as neglected 35–50 week pathways mature.
- **Recommendation**: Allocate 45% of marginal capacity to specialist surgical bottlenecks (`RRJ`), 30% to high-breach outpatient/daycase triage (`RRK` ENT), 15% to high-throughput daycase cataracts (`RRK` Ophthalmology), and 10% to routine acute surgery.

### 4. Create Protected High-Volume Low-Complexity (HVLC) Cataract Hubs
- **Finding**: Ophthalmology represents 625,063 waiting pathways nationally and 9,466 at `RRK` (3,277 breaching 18w).
- **Recommendation**: Expand dedicated weekend and extended-hours cataract lists operating at $\ge 8$ cases per 4-hour list (GIRFT benchmark). This rapidly clears high patient volumes with zero inpatient bed footprint.

### 5. Overhaul ENT Outpatient Triage and "Super-Clinics"
- **Finding**: ENT has the highest 18-week breach rate (42.7% nationally, 32.3% at `RRK`), driven primarily by outpatient clinic capacity rather than operating theatre constraints.
- **Recommendation**: Deploy multi-disciplinary diagnostic triage hub clinics (audiology and nurse-led micro-suction) prior to consultant outpatient slots, discharging or treating non-surgical cases in a single visit.

---

## 3. Practical Conversion Factors for Capacity Planning

To convert pathway reduction targets into tangible physical resources:
- **100 Completed T&O Inpatient Pathways** $\approx$ **45 Operating Theatre Sessions** (4-hour) + **280 Inpatient Bed-Days** + **150 Follow-up Outpatient Slots**.
- **100 Completed Ophthalmology Daycase Pathways** $\approx$ **12 Operating Theatre Sessions** + **0 Inpatient Beds** + **100 Diagnostic Optometry Slots**.
- **100 Completed ENT Outpatient Pathways** $\approx$ **8 Outpatient Clinic Sessions** + **0 Theatre Hours**.
