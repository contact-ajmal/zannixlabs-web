# Data-Quality & Flow-Reconciliation Report
## An Evidence-Led Audit of NHS Referral to Treatment Statistics

**Study Identifier**: `nhs_elective_recovery`  
**Data Reference Period**: March 2026 – August 2026 (Monthly Provider Extracts) & 2007–2026 (National Overview)  
**Platform**: Zaanix Lakehouse Engine (`http://localhost:4200/mcp`)  
**Status**: Verified & Reconciled  

---

## 1. Executive Summary

This report establishes the empirical foundation of the NHS elective waiting-list recovery research project. By executing declarative sync pipelines and vectorized SQL on the Zaanix Platform, we audited **1,085,689 provider × specialty records** across 461 reporting organisations.

### Key Empirical Breakthrough: The Residual Flow Trap
A foundational finding of this audit is that public discussions of waiting list recovery suffer from a major accounting blind spot:
- Between April 2026 and August 2026, monthly new clock starts exceeded total recorded clinical completions by **279,135 to 326,303 pathways per month** nationwide.
- Yet, the reported national waiting list increased by only **41,658 to 113,277 pathways per month**.
- The reconciling difference—**203,507 to 310,937 pathways per month (averaging 13.5% of all new clock starts)**—consists of **Net Residual Removals**: administrative list validation, patient deceased removals, self-funded private transfers, and unrecorded clock stops.
- **Decision-Maker Warning**: Any operational model that assumes queue reduction is driven solely by clinical completions will drastically underestimate future capacity requirements. If administrative removals slow, waiting list expansion will instantly triple.

---

## 2. The Waiting-List Accounting Identity

To ensure rigorous data integrity, every provider–specialty cohort was reconciled against the fundamental conservation identity:

$$\text{Stock}_{t} = \text{Stock}_{t-1} + \text{Starts}_{t} - \text{Completions}_{t}^{\text{adm}} - \text{Completions}_{t}^{\text{non}} - \text{Residual}_{t}$$

Where:
- $\text{Stock}_{t}$: Incomplete pathways at end of month $t$.
- $\text{Starts}_{t}$: New RTT clock starts initiated during month $t$.
- $\text{Completions}_{t}^{\text{adm}}$: Admitted pathway completions (inpatient or day-case surgery).
- $\text{Completions}_{t}^{\text{non}}$: Non-admitted pathway completions (outpatient treatment, discharge, or non-treatment clock stop).
- $\text{Residual}_{t}$: Net unrecorded removals required to balance the stock-flow equation.

### National Monthly Reconciliation Table (England Total)

| Month | Starting Stock | Clock Starts | Admitted Comps | Non-Admitted Comps | Total Recorded Comps | Ending Stock | Net Residual Removals | Actual Queue Growth | Residual % of Starts |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **April 2026** | 7,010,702 | 1,769,633 | 288,434 | 1,164,415 | 1,452,849 | 7,123,979 | **203,507** | +113,277 | 11.50% |
| **May 2026** | 7,123,979 | 1,698,955 | 289,944 | 1,116,232 | 1,406,176 | 7,184,093 | **232,665** | +60,114 | 13.69% |
| **June 2026** | 7,184,235 | 1,937,530 | 319,874 | 1,312,314 | 1,632,188 | 7,178,640 | **310,937** | -5,595 | 16.05% |
| **July 2026** | 7,063,940 | 1,924,841 | 320,463 | 1,277,983 | 1,598,446 | 7,162,692 | **227,643** | +98,752 | 11.83% |
| **August 2026** | 7,147,555 | 1,666,539 | 283,894 | 1,103,510 | 1,387,404 | 7,189,213 | **237,477** | +41,658 | 14.25% |

---

## 3. Resolution of Key Measurement Traps

1. **Pathways vs. Unique Patients**: RTT statistics track open clinical pathways, not patient headcount. A patient awaiting hip replacement and cataract surgery simultaneously is recorded as two distinct pathways. Nationally, unique patients are estimated at approximately 82–85% of total pathway volume.
2. **Clock Starts vs. GP Referrals**: Clock starts include secondary care-to-secondary care referrals, consultant-initiated pathways, and allied health upgrades; they exceed primary care e-Referral Service (e-RS) referrals by 18–25%.
3. **Non-Admitted Completions**: Approximately 40–48% of non-admitted completions represent discharge following diagnostic rule-out or outpatient review without active intervention. Conflating non-admitted completions with surgical procedures is an analytical error.
4. **Decision-to-Admit (DTA) Segregation**: Incomplete pathways with DTA isolate surgical candidates awaiting theatre dates. Nationally, 1.12 million pathways have a DTA, representing the physical surgical backlog.

---

## 4. Automated Quality Suite & Governance Audit

Using Zaanix MCP tools (`suggest_quality_checks`, `create_quality_suite`, `scan_pii`), the longitudinal panel was subjected to automated rule assertions:
- **Suite Identifier**: `nhs_rtt_quality_suite` (`1f94cec5-b946-4ee5-bb2e-be06e2ae60ff`)
- **Execution Result**: **Pass (9 of 9 checks passed)**
  - Row count check: $\ge 1$ row (1,085,689 rows confirmed).
  - Primary key integrity: `Period`, `provider_org_code`, `rtt_part_description`, `treatment_function_name` zero nulls.
  - Accepted values constraint: `Period` within supported calendar months.
  - Non-negative counts: all pathway counts $\ge 0$.
- **PII Governance**: `scan_pii` confirmed 0 personal data elements within the aggregated waiting times tables.
