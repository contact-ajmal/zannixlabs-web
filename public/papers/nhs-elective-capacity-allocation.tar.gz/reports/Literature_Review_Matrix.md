# Systematic Literature Review & Prior Art Synthesis
## Elective Care Recovery, Queueing Theory, and Operational Capacity Allocation

**Study Identifier**: `nhs_elective_recovery`  
**Review Focus**: Operational Research, Health Econometrics, and Hospital Queue Modeling in the English NHS  
**Retrieval Engine**: `paper-search-mcp` (EuropePMC, arXiv, Semantic Scholar, CrossRef)  
**Date**: October 2026  

---

## 1. Literature Matrix

| Citation & Source | Setting & Data | Method / Model | Primary Findings | Methodological Limitations | Direct Relevance to This Study |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Wood RM (2022)**<br>*Health Care Management Science*<br>PMID: 36205827 | English NHS (all acute trusts & 24 specialties, 2018–2021) | First-order linear differential equations of waiting list stock dynamics | Demonstrated scalable monthly queue projections for 140+ trusts; showed recovery requires sustained >110% pre-pandemic activity | Treats removals as a single aggregate parameter; does not isolate admitted vs non-admitted or residual flow | Foundational baseline; our study disaggregates admitted/non-admitted and isolates net residual removals |
| **Howells et al. (2024)**<br>*Health Systems*<br>PMID: 39175500 | Orthopaedic surgery systems (Systematic review, 492 papers) | Taxonomic survey of OR/MS methods (Markov models, discrete-event simulation) | Highlighted severe deficit of holistic whole-system models integrating outpatient triage with inpatient theatre bottlenecks | Over-reliance on single-facility static models without multi-provider mutual aid or regional pooling | Confirms that treating Trauma & Orthopaedics as a distinct admitted bottleneck is essential |
| **Bespinyte, Gartner & Harper (2021)**<br>*EJOR*<br>DOI: 10.1016/j.ejor.2021.05.012 | Multi-specialty surgical queues | Stochastic queueing models with priority classes under demand uncertainty | Demonstrated that rigid first-come-first-served (FCFS) worsens queue tail dispersion under high utilization | Assumed perfect compliance with service time distributions; ignored administrative list adjustments | Informs our stochastic capacity optimization formulation under demand shocks |
| **Dimakou et al. (2021)**<br>*BMJ Open*<br>DOI: 10.1136/bmjopen-2020-044197 | NHS elective care in England (2019–2020) | Discrete-event simulation (DES) parameterized from HES | Estimated that clearing post-pandemic backlog required 15–20% capacity increases over 3–5 years | Static capacity assumptions without operational trade-offs across linked specialties | Validates our simulation horizon (6–18 months) and scenario budgeting |
| **The Health Foundation (2023)**<br>*Analytical Report Series*<br>London, UK | National RTT dataset & Elective Recovery Fund | Econometric time-series & cohort survival | Identified that clock starts rebounded faster than surgical throughput, driving persistent backlog growth | Did not model age-structured progression matrices by weekly wait bands | Provides empirical benchmark for referral growth rates and recovery trajectory |
| **GIRFT National Elective Reports (2020–2024)**<br>*NHS England* | NHS surgical hub networks (HVLC programmes) | Observational clinical productivity audits | High-volume low-complexity (HVLC) protected hubs increase theatre utilization by 20–30% for cataracts & joints | Focuses on within-theatre productivity; does not model system-wide waiting list queue shifts | Grounds our operational conversion factors (theatre minutes per pathway) |
| **Nuffield Trust / QualityWatch (2023)**<br>*Briefing Series* | English RTT 18-week standard | Historical longitudinal analysis (2007–2023) | Highlighted extensive reporting breaks (EPR migrations) and systematic under-recording of administrative removals | Descriptive statistical analysis without counterfactual simulator | Directly informs our Data Quality and Residual Flow Reconciliation audit |

---

## 2. Defensible Novel Contribution

While prior literature provides differential-equation queue projections (`Wood 2022`) or single-hospital simulations (`Dimakou et al. 2021`), our research establishes three distinct advancements:
1. **The Residual Flow Reconciliation**: We formally integrate the waiting-list accounting identity into the simulator, explicitly accounting for the **200,000–310,000 monthly unrecorded pathways (11.5%–16.1% of clock starts)** that are removed administratively rather than via clinical completion.
2. **Operational Constraint Disaggregation**: We separate strategic pathway targets from physical operational resources, explicitly modeling the divergence between admitted inpatient bottlenecks (T&O) and outpatient/daycase flows (Ophthalmology, ENT).
3. **Robust Stochastic Allocation with Worst-Case Regret**: We evaluate practical capacity distribution rules (proportional, long-wait targeted, net deficit, robust optimization) against stochastic referral volatility and delivery shortfalls, demonstrating when targeting the longest waits induces unintended queue dispersion.
