# Policy Evaluation & Sensitivity Analysis Report
## Stochastic Simulation of NHS Elective Capacity Allocation

**Study Identifier**: `nhs_elective_recovery`  
**Execution Environment**: Zaanix Lakehouse Engine (`execute_query`)  
**Simulation Design**: 50 Monte Carlo runs per policy under log-normal demand shocks and uniform delivery execution risk  
**Horizon**: 12 Months (with 6- and 18-month sensitivity checks)  

---

## 1. Comparative Policy Performance

Under an identical additional capacity allocation of **500 completed pathways per month** across the Birmingham and Solihull ICB elective health economy:

| Policy Formulation | Cumulative Pathway-Weeks >52w ($\Omega_{12}$) | % Reduction vs. Status Quo | Ending Tail (>65w) | Ending Stock (Total) | Tail Reduction (%) | Robust Rank Stability |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **Policy 0: Status Quo (Zero Add. Cap.)** | 677,842 $\pm$ 24,190 | 0.00% | 3,005 | 33,726 | 0.0% | 6 / 6 (Worst) |
| **Policy 1: Proportional to Total Queue** | 388,264 $\pm$ 14,830 | 42.72% | 1,008 | 27,726 | 66.5% | 3 / 6 |
| **Policy 2: Targeted by Long-Wait Burden** | 388,378 $\pm$ 14,810 | 42.70% | 1,000 | 27,726 | 66.7% | 4 / 6 |
| **Policy 3: Targeted by Net Inflow Deficit**| 409,574 $\pm$ 15,340 | 39.58% | 1,176 | 27,726 | 60.9% | 5 / 6 |
| **Policy 4: Greedy Marginal Benefit** | 386,850 $\pm$ 14,750 | 42.93% | 1,006 | 27,726 | 66.5% | 2 / 6 |
| **Policy 5: Robust Stochastic Min-Max** | **385,073 $\pm$ 14,680**| **43.19%** | **998** | **27,726** | **66.8%** | **1 / 6 (Optimal)** |

---

## 2. Key Analytical Insights

### 1. Superiority of Robust Stochastic Allocation (Policy 5)
Policy 5 achieves the lowest cumulative patient suffering ($\Omega_{12} = 385,073$ pathway-weeks) and successfully compresses the ultra-long tail ($>65$ weeks) from 3,005 down to 998 pathways. It outperforms standard proportional allocation by weighting specialist surgical capacity (`RRJ` Orthopaedics) while maintaining critical outpatient throughput in high-breach queues (`RRK` ENT).

### 2. The Net Inflow Deficit Paradox (Policy 3 Underperformance)
Targeting capacity purely where inflows exceed outflows (Policy 3) produces the **worst recovery trajectory** among active interventions (39.58% reduction vs 43.19% for Policy 5). Why?
Because high-volume outpatient churn services (e.g. general dermatology, minor medical reviews) display large absolute differences between starts and completions, absorbing capacity that would otherwise clear stagnant, high-harm inpatient surgical candidates.

### 3. The Displacement Trap in Naive Long-Wait Targeting
When capacity is targeted exclusively at $>52$-week pathways (Policy 2), routine pathways in the 35–50 week window are neglected. Over 12 months, this creates an "echo breach wave," where pathways transition into $>52$-week status at accelerated rates, causing Policy 2 to slip behind Policy 4 and Policy 5 in month 9–12 stability.

---

## 3. Rigorous Sensitivity & Stress Testing

### A. Demand Volatility Shocks ($\pm 20\%$)
Under a $+20\%$ demand surge (influx of post-strike referrals):
- Status Quo backlog expands to $>39,000$ pathways.
- Policy 5 retains a 41.8% reduction in $\Omega_{12}$, maintaining its rank 1 position across 94% of simulation iterations.

### B. Delivery Shortfall (Capacity Realisation Dropping to 70%)
If staffing constraints (theatre nurse vacancies, anaesthetist sickness) restrict delivered additional capacity to 70% of planned targets:
- Cumulative long-wait weeks rise to 472,600.
- Policy 5 regret remains bounded, outperforming Policy 1 by 14,200 pathway-weeks.

### C. Zero-Residual Flow Stress Test (Administrative Removal Cessation)
If all administrative validation and net residual removals cease ($R=0$):
- Waiting lists expand across all providers at an additional $+3,940$ pathways/month at `RRK` alone.
- This proves that **system stabilization currently relies heavily on administrative cleansing**.
