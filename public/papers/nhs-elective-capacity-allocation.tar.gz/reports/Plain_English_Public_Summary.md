# Where Should Extra NHS Hospital Appointments and Operations Go?
## A Plain-English Public Summary of the ZannixLabs Waiting List Study

### Why Does This Research Matter?
Over 7.1 million hospital appointments and operations are currently on the waiting list in England. Behind every number is a person living with hip pain, deteriorating vision, hearing loss, or anxiety about when their treatment will happen.

Governments and hospitals frequently debate how much extra money or surgical capacity to provide. But an equally important question is: **Where should that extra capacity actually go?**

If a hospital has 10 extra surgical sessions this month, should they go to the specialty with the biggest total list, the patients who have waited the longest, or the queues that are growing fastest?

---

### What Did We Discover?

1. **The "Disappearing Patients" Phenomenon (The Residual Flow Trap)**:
   Every month across England, around **230,000 patients** are taken off the waiting list without having had an operation or hospital clinic treatment recorded. These are mostly people removed during administrative checks (for example, people who had treatment privately, moved away, or decided they no longer needed care).
   *Why this matters*: Hospitals cannot assume the waiting list is getting smaller just because doctors are doing more surgery. A huge part of waiting list reduction has come from paperwork reviews, not extra operations.

2. **Different Surgeries Have Very Different Bottlenecks**:
   - **Orthopaedics (Hips and Knees)**: Takes long theatre hours and hospital beds. If an emergency patient needs a bed, orthopaedic surgery gets cancelled.
   - **Eye Care (Cataracts)**: Fast, day-case surgery that doesn't need overnight beds.
   - **Ear, Nose & Throat (ENT)**: Massive delays happen before patients ever see a specialist, stuck in outpatient queues.

3. **Treating Only the Longest Waits Can Backfire**:
   If managers focus 100% of their energy only on patients waiting over 52 weeks, patients who have been waiting 40 weeks get neglected. A year later, those 40-week patients turn into an even bigger wave of 52-week breaches.

4. **A Smarter, Balanced Approach (Policy 5)**:
   Using computer simulations of patient queues, we showed that a balanced strategy that protects specialist orthopaedic surgical centres (like the Royal Orthopaedic Hospital in Birmingham) while creating fast-track diagnostic eye and ear hubs cuts total waiting time by **over 43%** and slashes ultra-long waits (>65 weeks) by **two-thirds**.

---

### What We Are Recommending Next
We recommend that local healthcare leaders in Birmingham and Solihull pilot a **shared regional scheduling system** so that patients waiting for routine joint surgery at general hospitals can have their operations at protected elective surgical centres without facing winter emergency cancellations.
