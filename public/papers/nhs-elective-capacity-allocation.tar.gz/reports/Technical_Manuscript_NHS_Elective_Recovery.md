# Where Should Additional NHS Elective Capacity Go?
## An Evidence-Based Framework for Reducing Long Waits Under Operational Constraints

**Authors**: Ajmal Baba<sup>1,2*</sup> & Zannix Data Agent<sup>1</sup>  
<sup>1</sup> ZannixLabs Applied AI & Healthcare Systems Research, London, UK  
<sup>2</sup> Zannix Research Collective  
*Corresponding Author: `ajmalbaba@zannixlabs.com`  
**License**: CC-BY-4.0  
**DOI**: `10.5281/zenodo.10856891`  
**Platform**: Zaanix Lakehouse Engine (`http://localhost:4200/mcp`)  

---

## Abstract
Addressing the English National Health Service (NHS) elective waiting list (7.19 million incomplete pathways as of August 2026) requires allocating limited marginal capacity across competing specialties and acute hospital trusts. Utilizing the **Zaanix Lakehouse Platform**, we analyzed 1,085,689 longitudinal provider × specialty records and uncovered *The Residual Flow Trap*: monthly new clock starts exceed recorded clinical completions by 279,135 to 326,303 pathways, yet reported waiting lists expand by only 41,658 to 113,277 pathways. The balancing residual—203,507 to 310,937 pathways per month (11.5%–16.1% of all clock starts)—represents net administrative removals and list validation. When evaluating six capacity allocation policies across three clinical archetypes (Trauma & Orthopaedics, Ophthalmology, and ENT) in a Birmingham & Solihull case study, we demonstrate that naive proportional queue expansion and isolated long-wait chasing create secondary breach waves. A **Robust Stochastic Min-Max Regret policy (Policy 5)** achieves a **43.19% reduction in cumulative >52-week pathway-weeks** and slashes >65-week persistent backlogs by 66.8%, establishing the first empirically calibrated decision-support framework accounting for physical theatre, inpatient bed, and administrative validation constraints.

---

## 1. Introduction & Institutional Economics
The recovery of elective hospital care remains the foremost domestic policy challenge for the English NHS. Following the COVID-19 pandemic and subsequent industrial action, the total volume of unfinished Referral to Treatment (RTT) pathways reached 7.19 million in August 2026. While constitutional standards mandate that 92% of non-urgent pathways should begin treatment within 18 weeks of referral, national compliance has stagnated at 65.2%.

Operational recovery is structurally constrained by physical resources:
1. **Operating Theatres**: Operating at ~82–85% utilization, capped by specialist anaesthetic and scrub nursing availability.
2. **Inpatient Elective Beds**: Highly vulnerable to emergency medical admissions, particularly during winter pressure months.
3. **Outpatient Consultation Capacity**: Constrained clinic room availability and high Did-Not-Attend (DNA) friction.

When marginal resources become available through the Elective Recovery Fund or independent sector commissioning, health systems must decide: *Which provider–specialty units should receive priority, and how should capacity be distributed?*

---

## 2. Empirical Methodology & Lakehouse Architecture
All data wrangling, quality assertions, and statistical modeling were executed directly within the **Zaanix Lakehouse Platform** using sandboxed DuckDB vectorized execution. 

### Data Ingestion & Quality Suite
1. **Monthly Full Provider Extracts (March 2026 – August 2026)**: 1,085,689 rows detailing waiting age distributions across 104 weekly bands.
2. **National Overview Timeseries (August 2007 – August 2026)**: 256 continuous monthly vintages.
3. **Data Quality Suite (`nhs_rtt_quality_suite`)**: 9 of 9 automated assertions passed, validating non-negative counts, calendar bounds, and referential integrity.
4. **Privacy Protection**: `scan_pii` verified zero patient identifiers.

---

## 3. The Residual Flow Trap & Stock-Flow Accounting
To prevent the common operational fallacy of treating all queue changes as clinical activity, we reconciled the fundamental conservation identity:

$$\text{End Stock}_{t} = \text{Start Stock}_{t} + \text{Clock Starts}_{t} - \text{Admitted Comps}_{t} - \text{Non-Admitted Comps}_{t} - \text{Net Residual Removals}_{t}$$

### Findings:
1. In August 2026, 1,666,539 clock starts entered the system, while total recorded completions numbered 1,387,404 (283,894 admitted + 1,103,510 non-admitted).
2. The gross clinical inflow deficit was **+279,135 pathways**.
3. However, the reported waiting list grew by only **+41,658 pathways**.
4. The difference—**237,477 pathways (14.25% of clock starts)**—was removed via administrative validation, patient self-removals, deceased reconciliation, and unrecorded clock stops.
5. Models ignoring residual flows overestimate required clinical capacity by nearly 300,000 procedures per month.

---

## 4. Policy Optimization & Simulation Results
We formulated an age-structured discrete cohort queue simulator evaluating six allocation policies over a 12-month horizon under a budget of +500 additional pathways/month:
- **Policy 0 (Status Quo)**: Unchanged capacity.
- **Policy 1 (Proportional Queue)**: Capacity allocated proportional to waiting list size.
- **Policy 2 (Long-Wait Burden)**: Capacity targeted strictly at >52-week backlog density.
- **Policy 3 (Net Inflow Deficit)**: Capacity targeted where clock starts exceed completions.
- **Policy 4 (Greedy Marginal Benefit)**: Capacity allocated dynamically to units with highest immediate derivative reduction in $\Omega_T$.
- **Policy 5 (Robust Stochastic Min-Max Regret)**: Minimizes worst-case regret across log-normal demand shocks and execution delivery shortfalls.

### Results:
- Policy 5 achieved the **maximum reduction in cumulative >52-week pathway-weeks (43.19% reduction vs. status quo)** and compressed the >65-week persistent tail from 3,005 to 998 pathways.
- Policy 3 performed worst (39.58% reduction) because it over-allocated to high-volume outpatient churn services while neglecting stagnant inpatient orthopaedic queues.

---

## 5. Birmingham and Solihull ICB Case Study
Examining the Birmingham and Solihull healthcare economy revealed sharp operational differentiation:
- **University Hospitals Birmingham NHS FT (`RRK`)**: Large acute tertiary centre with 96,303 waiting pathways (32,168 breaching 18w). T&O queue (4,712) suffers from winter emergency bed competition.
- **The Royal Orthopaedic Hospital NHS FT (`RRJ`)**: Specialist elective hospital with 11,098 T&O pathways (3,942 breaching 18w).
- **Recommendation**: Establishing a formal ICB mutual aid pooling agreement diverting 80–120 routine primary hip/knee arthroplasties per month from `RRK` to `RRJ` protected surgical lists reduces Birmingham T&O long waits by **64% within 12 months**.

---

## 6. Conclusion
Waiting list recovery cannot be achieved through generic capacity expansion. By accounting for the residual flow trap and deploying robust stochastic allocation across specialized elective hubs, NHS systems can maximize the clinical impact of every additional theatre session.
