# Prospective Local Validation & Clinical Pilot Proposal
## Multi-Provider Elective Capacity Pooling in Birmingham and Solihull ICB

**Pilot Title**: The Birmingham & Solihull Elective Coordination Initiative (BSECI)  
**Target Health Economy**: NHS Birmingham and Solihull Integrated Care Board (ICB)  
**Participating Trusts**:
- University Hospitals Birmingham NHS Foundation Trust (`RRK`)
- The Royal Orthopaedic Hospital NHS Foundation Trust (`RRJ`)
- Birmingham Women's and Children's NHS Foundation Trust (`RQ3`)  
**Proposed Pilot Duration**: 6 Months (November 2026 – April 2027)  

---

## 1. Pilot Objectives & Operational Scope

1. **Orthopaedic Surgical Hub Mutual Aid**: Divert 80–120 routine elective hip and knee primary arthroplasty pathways per month from `RRK` (Queen Elizabeth / Heartlands sites) to protected ring-fenced surgical lists at `RRJ`.
2. **High-Volume Daycase Cataract Acceleration**: Establish dedicated weekend high-flow cataract lists at `RRK` Solihull Hospital operating to GIRFT HVLC standards ($\ge 8$ cases per 4-hour list).
3. **ENT Pre-Clinic Audiology & Allied Health Triage**: Screen routine adult ENT referrals using specialist audiologist and nurse-led micro-suction triage clinics prior to consultant outpatient allocation.

---

## 2. Governance, Data Integration & Clinical Safeguards

### A. Patient Consent & Choice Architecture
- Participating patients retain full NHS Choice rights. Patients are proactively contacted with an option to transfer to `RRJ` for their surgery with a guaranteed 6-week theatre date.
- Elapsed waiting time is fully preserved under RTT rules.

### B. Shared Clinical Prioritisation Protocol
- Triage follows Federation of Surgical Specialty Associations (FSSA) clinical prioritization codes (P2, P3, P4).
- Cancer pathways (62-day standard) and acute trauma cases are completely protected from displacement.

### C. Information Governance & Electronic Patient Records
- Shared waiting list access established via the West Midlands Care Record (WMCR) and inter-trust EPR interoperability bridges.

---

## 3. Evaluation Design & Success Criteria

### Quantitative Metrics
1. **Primary Metric**: Reduction in Birmingham & Solihull cumulative pathway-weeks $>52w$ compared to pre-pilot baseline.
2. **Cancellation Rate**: Percentage of elective surgical lists cancelled due to acute emergency bed pressures (target: $<1.5\%$ at `RRJ` hub vs. historical $7.8\%$ at `RRK` acute sites).
3. **Theatre Utilization**: Mean operating minutes utilized per 4-hour list (target: $\ge 85\%$).
4. **Patient Reported Outcomes (PROMs)**: EQ-5D-5L and Oxford Hip/Knee Scores measured pre-op and at 6 months post-op.

### Stopping Rules & Safety Checks
- The pilot will pause immediately if patient refusal rates exceed 40%, surgical complication rates diverge significantly from national NJR baselines, or downstream community physiotherapy capacity is exhausted.
